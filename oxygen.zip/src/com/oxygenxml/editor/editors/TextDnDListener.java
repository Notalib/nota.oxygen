/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package com.oxygenxml.editor.editors;

import org.eclipse.jface.text.IDocument;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.dnd.DropTargetEvent;
import org.eclipse.swt.dnd.Transfer;

import ro.sync.ecss.extensions.api.SWTExtension;

/**
 * Text Drag and Drop listener interface for the SWT implementation.
 * The <code>TextDnDListener</code> class provides event notification to the Oxygen 
 * extension for DropTarget events occurring in the Text page.
 *
 * <p>As the user moves the cursor into, over and out of the text editor page,
 * events indicate what operation can be performed and what data can be 
 * transferred if a drop where to occur at that point.
 * The listener can respond to these events and change the type of data that will 
 * be dropped by modifying event.currentDataType, or change the operation that will be performed 
 * by modifying the event.detail field or stop any drop from happening on the current target
 * by setting the event.detail field to DND_DROP_NONE.</p>
 *
 * <p>When the user causes a drop to happen by releasing the mouse over the text editor page, 
 * the listener has one last chance to change the data type of the drop through the 
 * DropAccept event.  If the drop is still allowed, the DropAccept event is immediately 
 * followed by the Drop event.  In the Drop event, the listener can still change the
 * operation that is performed but the data type is fixed.</p>
 */
public interface TextDnDListener extends SWTExtension {
  /**
   * Returns <code>true</code> if the {@link DropTargetEvent} is 
   * relevant for the listener and its information
   * will be used in the other methods of this listener.
   * 
   * @param event The {@link DropTargetEvent} to check
   * @return <code>true</code> if the given event is of interest for the listener.
   */
  boolean isTextEventOfInterest(DropTargetEvent event);

  /**
   * Get the data transfers of interest for the listener.
   * 
   * @return An array of {@link Transfer} objects representing the
   * data transfers this listener is interested in.
   */
  Transfer[] getTextTransfers();
  
  /**
   * The cursor has entered the text editor page boundaries while dragging.
   * <br/>
   * For more details see {@link org.eclipse.swt.dnd.DropTargetListener#dragEnter(DropTargetEvent)} and
   * {@link DropTargetEvent} javadoc.
   *
   * @param event The information associated with the drag enter event.
   */
  void textDragEnter(DropTargetEvent event);
  
  /**
   * The cursor has leaved the text editor page boundaries while dragging.
   * <br/>
   * For more details see {@link org.eclipse.swt.dnd.DropTargetListener#dragLeave(DropTargetEvent)} and
   * {@link DropTargetEvent} javadoc.
   *
   * @param event The information associated with the drag leave event.
   */
  void textDragLeave(DropTargetEvent event);

  /**
   * The drag operation being performed has changed (usually due to the user changing the selected modifier key(s)
   * while dragging).
   * <br/>
   * For more details see {@link org.eclipse.swt.dnd.DropTargetListener#dragOperationChanged(DropTargetEvent)} 
   * and {@link DropTargetEvent} javadoc.
   *
   * @param event The information associated with the drag operation changed event.
   */
  void textDragOperationChanged(DropTargetEvent event);

  /**
   * The cursor is moving over the text editor page while dragging.
   * <br/>
   * For more details see {@link org.eclipse.swt.dnd.DropTargetListener#dragOver(DropTargetEvent)} and
   * {@link DropTargetEvent} javadoc.
   *
   * @param event The information associated with the drag over event.
   */
  void textDragOver(DropTargetEvent event);

  /**
   * The data is being dropped in the text editor page.  
   * The data field contains java format of the data being dropped.  
   * To determine the type of the data object, refer to the documentation for the {@link Transfer} subclass 
   * specified in event.currentDataType.
   * <br/>
   * For more details see {@link org.eclipse.swt.dnd.DropTargetListener#drop(DropTargetEvent)} and
   * {@link DropTargetEvent} javadoc.
   *
   * @param event The information associated with the drop event.
   */
  void textDrop(DropTargetEvent event);

  /**
   * The drop is about to be performed.  
   * The listener is given a last chance to change the nature of the drop.
   * <br/>
   * For more details see {@link org.eclipse.swt.dnd.DropTargetListener#dropAccept(DropTargetEvent)}
   * and {@link DropTargetEvent} javadoc. 
   * 
   * @param event The information associated with the drop accept event.
   */
  void textDropAccept(DropTargetEvent event);
  
  /**
   * Initialize the DnD listener.
   * 
   * @param text The text component from the text editor page.
   * @param document The document from the text editor page.
   * @param systemID The system ID of the document.
   */
  void init(StyledText text, IDocument document, String systemID);
}