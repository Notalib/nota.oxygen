/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.dita.map.topicref;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

import javax.xml.transform.sax.SAXSource;

import org.apache.log4j.Logger;
import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXNotRecognizedException;
import org.xml.sax.SAXNotSupportedException;
import org.xml.sax.XMLReader;

import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.ValidatingReferenceResolverException;
import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorDocument;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.ecss.extensions.dita.conref.DITAConRef;
import ro.sync.ecss.extensions.dita.conref.DITAConRefResolver;
import ro.sync.ecss.extensions.dita.conref.DITAXMLReaderWrapper;

/**
 * Resolves the hrefs to other maps.
 */
public class DITAMapRefResolver extends DITAConRefResolver {
  
  /**
   * Logger for logging. 
   */
  private static Logger logger = Logger.getLogger(DITAMapRefResolver.class.getName());
  /**
   * The <code>href</code> attribute.
   */
  private static final String ATTRIBUTE_HREF = "href";
  
  /**
   * The <code>scope</code> attribute.
   */
  private static final String ATTRIBUTE_SCOPE = "scope";
  
  /**
   * The <code>format</code> attribute.
   */
  private static final String ATTRIBUTE_FORMAT = "format";

  /**
   * An element that has <code>href</code> attribute 
   * is an element with references.
   * 
   * @see ro.sync.ecss.extensions.api.AuthorReferenceResolver#hasReferences(ro.sync.ecss.extensions.api.node.AuthorNode)
   */
  @Override
  public boolean hasReferences(AuthorNode node) {
    boolean hasReferences = getHref(node) != null;
    if(! hasReferences) {
      hasReferences = super.hasReferences(node);
    }
    return hasReferences;
  }

  /**
   * Get the href value for a node.
   * @param node The node
   * @return the href value or null.
   */
  private String getHref(AuthorNode node) {
    String href = null;
    if (node.getType() == AuthorNode.NODE_TYPE_ELEMENT) {
      AuthorElement element = (AuthorElement) node;
      AttrValue hrefValue = element.getAttribute(ATTRIBUTE_HREF);
      if(hrefValue != null) {
        AttrValue scopeValue = element.getAttribute(ATTRIBUTE_SCOPE);
        if(scopeValue == null || ! "external".equals(scopeValue.getValue())) {
          AttrValue formatValue = element.getAttribute(ATTRIBUTE_FORMAT);
          if(formatValue != null && formatValue.getValue().equals("ditamap")) {
            href = hrefValue.getValue();
          }
        }
      }
    }
    return href;
  }
  
  /**
   * Returns the value of the <code>href</code> attribute.
   * 
   * @see ro.sync.ecss.extensions.api.AuthorReferenceResolver#getDisplayName(ro.sync.ecss.extensions.api.node.AuthorNode)
   */
  @Override
  public String getDisplayName(AuthorNode node) {
    String displayName = getHref(node);
    if(displayName == null) {
      return super.getDisplayName(node);
    }
    return displayName;
  }
  
  /**
   * Resolve the content referred by <code>conref</code> attribute.
   * 
   * @see ro.sync.ecss.extensions.api.AuthorReferenceResolver#resolveReference(ro.sync.ecss.extensions.api.node.AuthorNode, java.lang.String, AuthorAccess, EntityResolver)
   */
  @Override
  public SAXSource resolveReference(
      AuthorNode node, 
      String systemID, 
      AuthorAccess authorAccess,
      EntityResolver  entityResolver) {
    String href = getHref(node);
    if(href != null) {
      SAXSource saxSource = null;

      try {
        //Parse the reference
        DITAConRef conRef = parseDITAHref(systemID, href, authorAccess, true);
        if (conRef != null) {
          //Resolve the entity through catalog
          InputSource inputSource = entityResolver.resolveEntity(null, conRef.getUri());
          if(inputSource == null) {
            inputSource = new InputSource(conRef.getUri());
          }

          XMLReader xmlReader = authorAccess.getUtilAccess().newNonValidatingXMLReader();
          xmlReader.setEntityResolver(entityResolver);

          if(conRef.getTopicID() != null && conRef.getTopicID().length() > 0) {
            String[] topicPath = getTopicPath(conRef.getTopicID());            
            if (topicPath != null && topicPath.length > 0) {
              //Create the XML reader wrapper if this is the case.
              xmlReader = 
                new DITAXMLReaderWrapper(
                    xmlReader, 
                    topicPath, null);
            }
          }
          saxSource = new SAXSource(xmlReader, inputSource);
        }
      } catch (MalformedURLException e) {
        logger.error(e, e);
      } catch (SAXNotRecognizedException e) {
        logger.error(e, e);
      } catch (SAXNotSupportedException e) {
        logger.error(e, e);
      } catch (SAXException e) {
        logger.error(e, e);
      } catch (IOException e) {
        logger.error(e, e);
      } 
      
      return saxSource;
    } else {
      //Delegate to super for conref.
      return super.resolveReference(node, systemID, authorAccess, entityResolver);
    }
  }
  
  /**
   * Get the reference System ID
   * 
   * @see ro.sync.ecss.extensions.api.AuthorReferenceResolver#getReferenceSystemID(ro.sync.ecss.extensions.api.node.AuthorNode, AuthorAccess)
   */
  @Override
  public String getReferenceSystemID(AuthorNode node, AuthorAccess authorAccess) {
    String href = getHref(node);
    if (href != null) {
      String systemID = null;
      try {
        //Create the absolute system ID
        systemID = new URL(node.getXMLBaseURL(), href).toString();

        //Try to pass through catalog.
        DITAConRef parseDITAHref = parseDITAHref(
            node.getXMLBaseURL()  == null ? null : node.getXMLBaseURL().toString(), 
                href, authorAccess, true);
        if(parseDITAHref != null) {
          systemID = parseDITAHref.getUri();
          if(parseDITAHref.getTopicID() != null && parseDITAHref.getTopicID().length() > 0) {
            systemID +="#" + parseDITAHref.getTopicID();
          }
        }
      } catch (MalformedURLException e) {
        if (logger.isDebugEnabled()) {
          logger.debug(e, e);
        }
      }
      return systemID;
    } else {
      return super.getReferenceSystemID(node, authorAccess);
    }
  }
  
  /**
   * 
   * @see ro.sync.ecss.extensions.api.ValidatingAuthorReferenceResolver#checkTarget(ro.sync.ecss.extensions.api.node.AuthorNode, ro.sync.ecss.extensions.api.node.AuthorDocument)
   */
  @Override
  public void checkTarget(AuthorNode node, AuthorDocument targetDocument) throws ValidatingReferenceResolverException{
    if(getHref(node) != null) {
      //Do not validate source and target, topic reference.
    } else {
      //Maybe conref
      super.checkTarget(node, targetDocument);
    }
  }
  
  /**
   * The value of <code>conref</code> attribute is used as the unique identifier.
   * 
   * @see ro.sync.ecss.extensions.api.AuthorReferenceResolver#getReferenceUniqueID(ro.sync.ecss.extensions.api.node.AuthorNode)
   */
  @Override
  public String getReferenceUniqueID(AuthorNode node) {
    String id = getHref(node);
    if(id == null) {
      //Maybe conref
      return super.getReferenceUniqueID(node);
    }
    return id;
  }

  /**
   * Returns <code>true</code> when the attribute name is equal to <code>'conref'</code>.
   * 
   * @see ro.sync.ecss.extensions.api.AuthorReferenceResolver#isReferenceChanged(ro.sync.ecss.extensions.api.node.AuthorNode, java.lang.String)
   */
  @Override
  public boolean isReferenceChanged(AuthorNode node, String attributeName) {
    //Check for href or delegate for conref.
    return ATTRIBUTE_HREF.equals(attributeName) || super.isReferenceChanged(node, attributeName);
  }
}
