/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.dita.topic.table.simpletable;

/**
 * Provides elements and attributes information used in DITA simple table model.
 */
public interface SimpleTableConstants {
  
  /**
   * The name of the simpletable element.
   * The value is <code>simpletable</code>.
   */
  String ELEMENT_NAME_SIMPLETABLE = "simpletable";
  
  /**
   * The name of element that defines the header of a simpletable.
   * The value is <code>sthead</code>.
   * 
   */
  String ELEMENT_NAME_HEADER_SIMPLETABLE = "sthead";
  
  /**
   * The name of element that defines a simpletable row.
   * The value is <code>strow</code>.
   */
  String ELEMENT_NAME_ROW_SIMPLETABLE = "strow";
  
  /**
   * The name of element that defines a simpletable cell.
   * The value is <code>stentry</code>.
   */
  String ELEMENT_NAME_ENTRY_SIMPLETABLE = "stentry";
  
  /**
   * The name of the choicetable element.
   * The value is <code>choicetable</code>.
   */
  String ELEMENT_NAME_CHOICETABLE = "choicetable";
  
  /**
   * The name of element that defines the header of a choicetable.
   * The value is <code>chhead</code>.
   * 
   */
  String ELEMENT_NAME_HEADER_CHOICETABLE = "chhead";
  
  /**
   * The name of element that defines a choicetable row.
   * The value is <code>chrow</code>.
   */
  String ELEMENT_NAME_ROW_CHOICETABLE = "chrow";
  
  /**
   * The name of element that defines a choicetable header option cell.
   * The value is <code>choptionhd</code>.
   */
  String ELEMENT_NAME_CHOPTIONHD_CHOICETABLE = "choptionhd";

  /**
   * The name of element that defines a choicetable header description cell.
   * The value is <code>chdeschd</code>.
   */
  String ELEMENT_NAME_CHDESCHD_CHOICETABLE = "chdeschd";
  
  /**
   * The name of element that defines a choicetable description cell.
   * The value is <code>chdesc</code>.
   */
  String ELEMENT_NAME_CHDESC_CHOICETABLE = "chdesc";
  
  /**
   * The name of element that defines a choicetable option cell.
   * The value is <code>choption</code>.
   */
  String ELEMENT_NAME_CHOPTION_CHOICETABLE = "choption";
  
  /**
   * The name of the properties element.
   * The value is <code>properties</code>.
   */
  String ELEMENT_NAME_PROPERTIES = "properties";
  
  /**
   * The name of element that defines the header of a properties table.
   * The value is <code>prophead</code>.
   */
  String ELEMENT_NAME_HEADER_PROPERTIES = "prophead";
  
  /**
   * The name of element that defines a property row.
   * The value is <code>property</code>.
   */
  String ELEMENT_NAME_ROW_PROPERTIES = "property";
  
  /**
   * The name of element that defines the header property type cell.
   * The value is <code>proptypehd</code>.
   */
  String ELEMENT_NAME_PROPTYPEHD_PROPERTIES = "proptypehd";
  
  /**
   * The name of element that defines the header property value cell.
   * The value is <code>propvaluehd</code>.
   */
  String ELEMENT_NAME_PROPVALUEHD_PROPERTIES = "propvaluehd";
  
  /**
   * The name of element that defines the header property description cell.
   * The value is <code>propdeschd</code>.
   */
  String ELEMENT_NAME_PROPDESCHD_PROPERTIES = "propdeschd";
  
  /**
   * The name of element that defines the property type cell.
   * The value is <code>proptype</code>.
   */
  String ELEMENT_NAME_PROPTYPE_PROPERTIES = "proptype";
  
  /**
   * The name of element that defines the property value cell.
   * The value is <code>propvalue</code>.
   */
  String ELEMENT_NAME_PROPVALUE_PROPERTIES = "propvalue";
  
  /**
   * The name of element that defines the property description cell.
   * The value is <code>propdesc</code>.
   */
  String ELEMENT_NAME_PROPDESC_PROPERTIES = "propdesc";
  /**
   * The name of the identifier attribute.
   * The value is <code>id</code>.
   */
  String ATTRIBUTE_NAME_ID = "id";
}