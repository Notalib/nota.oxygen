/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.dita.topic.table.simpletable;

import java.util.Iterator;
import java.util.List;

import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.ecss.extensions.commons.table.operations.AuthorTableHelper;
import ro.sync.ecss.extensions.commons.table.operations.InsertColumnOperationBase;

/**
 * Operation used to insert a DITA simple table column.
 */
public class InsertColumnOperation extends InsertColumnOperationBase implements SimpleTableConstants {
  
  /**
   * Constructor.
   */
  public InsertColumnOperation() {
    this(new DITASimpleTableDocumentTypeHelper());
  }

  /**
   * Constructor.
   * 
   * @param documentTypeHelper Document type helper, has methods specific to a document type.
   */
  protected InsertColumnOperation(AuthorTableHelper documentTypeHelper) {
    super(documentTypeHelper);
  }

  /**
   * @see ro.sync.ecss.extensions.commons.table.operations.InsertColumnOperationBase#getCellElementName(ro.sync.ecss.extensions.api.node.AuthorElement, int)
   */
  @Override
  protected String getCellElementName(AuthorElement rowElement, int newColumnIndex) {
    String rowName = rowElement.getLocalName();
    if (ELEMENT_NAME_ROW_SIMPLETABLE.equals(rowName)
      // simpletable row
        || ELEMENT_NAME_HEADER_SIMPLETABLE.equals(rowName)) {
      return ELEMENT_NAME_ENTRY_SIMPLETABLE;
    } else if (ELEMENT_NAME_ROW_CHOICETABLE.equals(rowName)) {
      // chioicetable row
      return getCellName(
          rowElement, 
          new String[] {ELEMENT_NAME_CHOPTION_CHOICETABLE, ELEMENT_NAME_CHDESC_CHOICETABLE}, 
          newColumnIndex);
    } else if (ELEMENT_NAME_HEADER_CHOICETABLE.equals(rowName)) {
      // choicetable header row
      return getCellName(
          rowElement, 
          new String[] {ELEMENT_NAME_CHOPTIONHD_CHOICETABLE, ELEMENT_NAME_CHDESCHD_CHOICETABLE}, 
          newColumnIndex);
    } else if (ELEMENT_NAME_ROW_PROPERTIES.equals(rowName)) {
      // properties table row
      return getCellName(
          rowElement, 
          new String[] {ELEMENT_NAME_PROPTYPE_PROPERTIES, ELEMENT_NAME_PROPVALUE_PROPERTIES, ELEMENT_NAME_PROPDESC_PROPERTIES}, 
          newColumnIndex);
    } else if (ELEMENT_NAME_HEADER_PROPERTIES.equals(rowName)) {
      // properties table header row
      return getCellName(
          rowElement, 
          new String[] {ELEMENT_NAME_PROPTYPEHD_PROPERTIES, ELEMENT_NAME_PROPVALUEHD_PROPERTIES, ELEMENT_NAME_PROPDESCHD_PROPERTIES}, 
          newColumnIndex);
    }
    return null;
  }
  
  /**
   * Get the name of the next cell that can be inserted
   * 
   * @param rowElement      The row element to insert the cell into.
   * @param possibleValues  The possible cell names.
   * @param newColumnIndex  The index where the cell can be inserted.
   * @return The cell name.
   */
  private String getCellName(AuthorElement rowElement, String[] possibleValues, int newColumnIndex) {
    String nextCellName = null;
    int cellIdx = 0;
    List<AuthorNode> children = rowElement.getContentNodes();
    if (!children.isEmpty()) {
      for (Iterator<AuthorNode> iterator = children.iterator(); iterator.hasNext();) {
        AuthorNode child = iterator.next();
        // Analyze the cell elements of the given row to see the name of the cell 
        // that can be inserted at the provided position
        if (child.getType() == AuthorNode.NODE_TYPE_ELEMENT) {
          String cellName = ((AuthorElement) child).getLocalName();
          // Found the cell before the inserted one.  
          if (cellIdx == newColumnIndex - 1) {
            for (int i = 0; i < possibleValues.length; i++) {
              if (possibleValues[i].equals(cellName)) {
                if (i < possibleValues.length - 1) {
                  nextCellName = possibleValues[i + 1];
                  break;
                }
              }
            }
          } else if (nextCellName != null) {
            if (cellName.equals(nextCellName)) {
              nextCellName = null;
              break;
            }
          }
          cellIdx ++;
        }
      }
    } else {
      // The row has no cell.
      nextCellName = possibleValues[0];
    }
    return nextCellName;
  }
}