/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.dita.conref;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.xml.sax.Attributes;
import org.xml.sax.ContentHandler;
import org.xml.sax.Locator;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;
import org.xml.sax.ext.Attributes2;
import org.xml.sax.ext.LexicalHandler;

import ro.sync.xml.ProxyNamespaceMapping;

/**
 * Content and lexical handler used to filter parser events outside 
 * the given topic IDs path.
 */
public class DITAFilteringContentHandler implements ContentHandler, LexicalHandler {
  
  /**
   * The wrapped {@link ContentHandler}.
   */
  private ContentHandler contentHandler;
  
  /**
   * The wrapped {@link LexicalHandler}.
   */
  private LexicalHandler lexicalHandler;
  
  /**
   * The topic ID path.
   */
  private String[] topicPath;
  
  /**
   * The index in the topic IDs path.
   */
  private int pathIndex;
  
  /**
   * Used to determine when we have reached the end of the referred fragment root.
   */
  private int referredPathDepth;
  
  /**
   * <code>true</code> if the events are forwarded to the wrapped content or lexical handlers.
   */
  private boolean isForwardingEvents;
  
  /**
   * The proxy namespace mapping.
   */
  private ProxyNamespaceMapping proxyNamespaceMapping = new ProxyNamespaceMapping();

  /**
   * If true the content reference was resolved.
   */
  private boolean referenceResolved = false;
  
  /**
   * True when parser is in DTD declaration
   */
  private boolean startDTD;

  /**
   * If a "conrefend" is specified, this is the end range path
   */
  private final String[] endRangePath;
  
  /**
   * The invalid range exception. Will stop the parsing
   */
  private SAXException invalidRangeException;
  
  /**
   * Depth of current element
   */
  private int depth = 0;
  
  /**
   * The start range depth
   */
  private int startRangeDepth = -1;

  /**
   * True if found the end range end element id
   */
  private boolean foundEndRangeElement;

  /**
   * QName of the start range element, must be the same with the QName of the end range element
   */
  private String startRangeElementQName;
  
  /**
   * Constructor.
   * 
   * @param topicPath The topic IDs path.
   * @param endRangePath If a "conrefend" is specified, this is the end range path
   */
  public DITAFilteringContentHandler(String[] topicPath, String[] endRangePath) {
    this.topicPath = topicPath;
    this.endRangePath = endRangePath;
    
    //The end and start ranges must have the same parent path. 
    if(endRangePath != null) {
      boolean invalidRange = false;
      if(endRangePath.length != topicPath.length) {
        invalidRange = true;
      } else {
        //Should be equal except the last ID.
        for (int i = 0; i < topicPath.length - 1; i++) {
          if(! topicPath[i].equals(endRangePath[i])) {
            invalidRange = true;
            break;
          }
        }
      }
      if(invalidRange) {
        invalidRangeException = createInvalidRangeException("Different parent paths.");
      }
    }
  }

  /**
   * Create the incompatible range exception
   * @param situation The particular situation
   * @return The exception
   */
  private SAXException createInvalidRangeException(String situation) {
    return new SAXException(
        "Problem when constructing conref range between \"" 
        + createConrefDescr(topicPath) 
        + "\" and \"" 
        + createConrefDescr(endRangePath) + "\" because: " + situation);
  }

  /**
   * Set the wrapped content handler.
   * 
   * @param contentHandler The contentHandler to set.
   */
  public void setContentHandler(ContentHandler contentHandler) {
    this.contentHandler = contentHandler;
  }
  
  /**
   * Set the wrapped lexical handler.
   * 
   * @param lexicalHandler The lexicalHandler to set.
   */
  public void setLexicalHandler(LexicalHandler lexicalHandler) {
    this.lexicalHandler = lexicalHandler;
  }
  
  /**
   * @see org.xml.sax.ContentHandler#characters(char[], int, int)
   */
  public void characters(char[] ch, int start, int length) throws SAXException {
    if (isForwardingEvents && contentHandler != null) {
      contentHandler.characters(ch, start, length);
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#endDocument()
   */
  public void endDocument() throws SAXException {
    if (contentHandler != null) {
      contentHandler.endDocument();
      
      if(!referenceResolved){
        String conref = createConrefDescr(topicPath);
        throw new SAXParseException("Content reference '" + conref + "' was not found.", null);
      }
    }
  }

  private static String createConrefDescr(String[] topicPath) {
    // conref was not resolved. Throw an exception to inform the user
    String conref = "";
    for (int i = 0; i < topicPath.length; i++) {
      conref += topicPath[i];
      
      if(i != topicPath.length - 1){
        conref += "/";
      }
    }
    return conref;
  }

  
  /**
   * @see org.xml.sax.ContentHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
   */
  public void endElement(String uri, String localName, String name) throws SAXException {
    depth --;
    if (isForwardingEvents) {
      if (contentHandler != null) {
        contentHandler.endElement(uri, localName, name);
      }
      
      if(endRangePath != null) {
        if(foundEndRangeElement && depth == startRangeDepth - 1) {
          //Stop now, the whole range was processed.
          isForwardingEvents = false;
          referenceResolved = true;
        } else if(depth < startRangeDepth - 1) {
          //Did not find the ID of the end range in the parent of the start range.
          throw createInvalidRangeException("Conrefend target element is not a sibling of the conref target element.");
        }
      } else {
        referredPathDepth --;
        if (referredPathDepth == 0) {
          isForwardingEvents = false;
          referenceResolved = true;
        }
      }
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#endPrefixMapping(java.lang.String)
   */
  public void endPrefixMapping(String prefix) throws SAXException {
    if (contentHandler != null) {
      contentHandler.endPrefixMapping(prefix);
    }
    if (!isForwardingEvents) {
      proxyNamespaceMapping.removeByPrefix(prefix);
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#ignorableWhitespace(char[], int, int)
   */
  public void ignorableWhitespace(char[] ch, int start, int length) throws SAXException {
    if (isForwardingEvents && contentHandler != null) {
      contentHandler.ignorableWhitespace(ch, start, length);
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#processingInstruction(java.lang.String, java.lang.String)
   */
  public void processingInstruction(String target, String data) throws SAXException {
    if (isForwardingEvents && contentHandler != null) {
      contentHandler.processingInstruction(target, data);
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#setDocumentLocator(org.xml.sax.Locator)
   */
  public void setDocumentLocator(Locator locator) {
    if (contentHandler != null) {
      contentHandler.setDocumentLocator(locator);
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#skippedEntity(java.lang.String)
   */
  public void skippedEntity(String name) throws SAXException {
    if (isForwardingEvents && contentHandler != null) {
      contentHandler.skippedEntity(name);
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#startDocument()
   */
  public void startDocument() throws SAXException {
    if(invalidRangeException != null) {
      throw invalidRangeException;
    }
    if (contentHandler != null) {
      contentHandler.startDocument();
    }
  }

  /**
   * @see org.xml.sax.ContentHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
   */
  public void startElement(String uri, String localName, String name, Attributes atts)
      throws SAXException {
    depth++;
    if (!isForwardingEvents && !referenceResolved) {
      String idValue = atts.getValue("id");
      if (idValue != null) {
        if (idValue.equals(topicPath[pathIndex])) {
          pathIndex ++;
          if (pathIndex == topicPath.length) {
            isForwardingEvents = true;
            startRangeDepth = depth;
            startRangeElementQName = name;
          }
        }
      }
    }
    
    if (isForwardingEvents) {
      if(endRangePath != null && depth == startRangeDepth) {
        String idValue = atts.getValue("id");
        if (idValue != null) {
          if (idValue.equals(endRangePath[endRangePath.length - 1])) {
            if(name.equals(startRangeElementQName)) {
              foundEndRangeElement = true;
            } else {
              throw createInvalidRangeException("Incompatible target elements types.");
            }
          }
        }
      }
      
      referredPathDepth ++;
      if(referredPathDepth == 1) {
        // Add the namespaces that are declared in element ancestors 
        AttrsImpl newAttributes = new AttrsImpl(atts);
        List proxies = proxyNamespaceMapping.getProxies();
        for (Iterator iterator = proxies.iterator(); iterator.hasNext();) {
          String proxy = (String) iterator.next();
          String namespace = proxyNamespaceMapping.getNamespaceForPrefix(proxy);
          
          if(!"".equals(namespace)) {
            String attrName = "xmlns";
            if(!"".equals(proxy)) {
              attrName += ":" + proxy;
            }

            newAttributes.addAttribute(attrName, namespace, false);
          }
        }
        atts= newAttributes;
      }

      contentHandler.startElement(uri, localName, name, atts);
    }
  }
  
  /**
   * @see org.xml.sax.ContentHandler#startPrefixMapping(java.lang.String, java.lang.String)
   */
  public void startPrefixMapping(String prefix, String uri) throws SAXException {
    proxyNamespaceMapping.addMapping(prefix, uri);
    contentHandler.startPrefixMapping(prefix, uri);
  }

  /**
   * @see org.xml.sax.ext.LexicalHandler#comment(char[], int, int)
   */
  public void comment(char[] ch, int start, int length) throws SAXException {
    if (isForwardingEvents && lexicalHandler != null) {
      lexicalHandler.comment(ch, start, length);
    }
  }

  /**
   * @see org.xml.sax.ext.LexicalHandler#endCDATA()
   */
  public void endCDATA() throws SAXException {
    if (isForwardingEvents && lexicalHandler != null) {
      lexicalHandler.endCDATA();
    }
  }

  /**
   * @see org.xml.sax.ext.LexicalHandler#endDTD()
   */
  public void endDTD() throws SAXException {
    startDTD = false;
    if (lexicalHandler != null) {
      lexicalHandler.endDTD();
    }
  }

  /**
   * @see org.xml.sax.ext.LexicalHandler#endEntity(java.lang.String)
   */
  public void endEntity(String name) throws SAXException {
    if (lexicalHandler != null && (isForwardingEvents || startDTD)) {
      lexicalHandler.endEntity(name);
    }
  }

  /**
   * @see org.xml.sax.ext.LexicalHandler#startCDATA()
   */
  public void startCDATA() throws SAXException {
    if (isForwardingEvents && lexicalHandler != null) {
      lexicalHandler.startCDATA();
    }
  }

  /**
   * @see org.xml.sax.ext.LexicalHandler#startDTD(java.lang.String, java.lang.String, java.lang.String)
   */
  public void startDTD(String name, String publicId, String systemId) throws SAXException {
    startDTD = true;
    if (lexicalHandler != null) {
      lexicalHandler.startDTD(name, publicId, systemId);
    }
  }

  /**
   * @see org.xml.sax.ext.LexicalHandler#startEntity(java.lang.String)
   */
  public void startEntity(String name) throws SAXException {
    if (lexicalHandler != null && (isForwardingEvents || startDTD)) {
      lexicalHandler.startEntity(name);
    }
  }
  
  /**
   * Returns <code>true</code> when both values are <code>null</code> or both are not <code>null</code> and equal.
   * 
   * @param str1 The first string value.
   * @param str2 The second string.
   * @return <code>true</code> if they are equal.
   */
  private static boolean areStringEqual(String str1, String str2) {
    return (str1 == null && str2 == null)
        || (str1 != null && str2 != null && str1.equals(str2));
  }

  /**
   * Container for attribute information.
   */
  private static class Attribute {
    
    /**
     * This attribut's namespace URI. 
     */
    private String uri;
    
    /**
     * This attribute's qualified name.
     */
    private String qName;
    
    /**
     * This attribute's local name.
     */
    private String localName;
    
    /**
     * This attribute's type.
     */
    private String type;
    
    /**
     * This attribute's value.
     */
    private String value;
    
    /**
     * <code>true</code> unless the attribute value was provided by DTD defaulting.
     */
    private final boolean isSpecified;
    
    /**
     * <code>false</code> unless the attribute was declared in the DTD.
     */
    private final boolean isDeclared;

    /**
     * Constructor.
     * 
     * @param uri The namespace URI.
     * @param qName The attribute qualified name.
     * @param localName The attribute local name.
     * @param type The attribute type.
     * @param value The attribute value.
     * @param isSpecified True unless the attribute value was provided by DTD defaulting.
     * @param isDeclared  False unless the attribute was declared in the DTD.
     */
    public Attribute(
        String uri, 
        String qName, 
        String localName, 
        String type, 
        String value, 
        boolean isSpecified, 
        boolean isDeclared) {
      this.uri = uri;
      this.qName = qName;
      this.localName = localName;
      this.type = type;
      this.value = value;
      this.isSpecified = isSpecified;
      this.isDeclared = isDeclared;
    }
  }
  
  /**
   * A simple implementation of <code>Attributes</code> interface.
   */
  private static class AttrsImpl implements Attributes2 {
    
    /**
     * The list of attributes.
     */
    private List attrs;
    
    /**
     * Constructor.
     * 
     * @param attributes The original attributes collection.
     */
    public AttrsImpl(Attributes attributes) {
      int length = attributes.getLength();
      attrs = new ArrayList(length);
      for (int i = 0; i < length; i ++) {
        boolean isDeclared = false;
        boolean isSpecified = true;
        if (attributes instanceof Attributes2) {
          Attributes2 attributes2 = (Attributes2) attributes;
          isDeclared = attributes2.isDeclared(i);
          isSpecified = attributes2.isSpecified(i);
        }
        attrs.add(
            new Attribute(
                attributes.getURI(i),
                attributes.getQName(i),
                attributes.getLocalName(i),
                attributes.getType(i),
                attributes.getValue(i),
                isSpecified, 
                isDeclared));
      }
    }
    
    /**
     * Add attribute.
     * 
     * @param attrName The attribute name.
     * @param value The attribute value.
     * @param specified True if specified
     */
    public void addAttribute(String attrName, String value, boolean specified) {
      attrs.add(new Attribute(null, attrName, attrName, null, value, specified, false));
    }

    /**
     * @see org.xml.sax.Attributes#getIndex(java.lang.String)
     */
    public int getIndex(String name) {
      int idx = -1;
      int i = -1;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        i ++;
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(name, attr.qName)) {
          idx = i;
          break;
        }
      }
      
      return idx;
    }

    /**
     * @see org.xml.sax.Attributes#getIndex(java.lang.String, java.lang.String)
     */
    public int getIndex(String uri, String localName) {
      int idx = -1;
      int i = -1;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        i ++;
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(uri, attr.uri) && areStringEqual(localName, attr.localName)) {
          idx = i;
          break;
        }
      }
      
      return idx;
    }

    /**
     * @see org.xml.sax.Attributes#getLength()
     */
    public int getLength() {
      return attrs.size();
    }

    /**
     * @see org.xml.sax.Attributes#getLocalName(int)
     */
    public String getLocalName(int index) {
      return ((Attribute) attrs.get(index)).localName;
    }

    /**
     * @see org.xml.sax.Attributes#getQName(int)
     */
    public String getQName(int index) {
      return ((Attribute) attrs.get(index)).qName;
    }

    /**
     * @see org.xml.sax.Attributes#getType(int)
     */
    public String getType(int index) {
      return ((Attribute) attrs.get(index)).type;
    }

    /**
     * @see org.xml.sax.Attributes#getType(java.lang.String)
     */
    public String getType(String name) {
      String type = null;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(name, attr.qName)) {
          type = attr.type;
          break;
        }
      }
      
      return type;
    }

    /**
     * @see org.xml.sax.Attributes#getType(java.lang.String, java.lang.String)
     */
    public String getType(String uri, String localName) {
      String type = null;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(uri, attr.uri) && areStringEqual(localName, attr.localName)) {
          type = attr.type;
          break;
        }
      }
      
      return type;
    }

    /**
     * @see org.xml.sax.Attributes#getURI(int)
     */
    public String getURI(int index) {
      return ((Attribute) attrs.get(index)).uri;
    }

    /**
     * @see org.xml.sax.Attributes#getValue(int)
     */
    public String getValue(int index) {
      return ((Attribute) attrs.get(index)).value;
    }

    /**
     * @see org.xml.sax.Attributes#getValue(java.lang.String)
     */
    public String getValue(String name) {
      String value = null;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(name, attr.qName)) {
          value = attr.value;
          break;
        }
      }
      
      return value;
    }

    /**
     * @see org.xml.sax.Attributes#getValue(java.lang.String, java.lang.String)
     */
    public String getValue(String uri, String localName) {
      String value = null;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(uri, attr.uri) && areStringEqual(localName, attr.localName)) {
          value = attr.value;
          break;
        }
      }

      return value;
    }

    /**
     * @see org.xml.sax.ext.Attributes2#isDeclared(int)
     */
    public boolean isDeclared(int index) {
      return ((Attribute) attrs.get(index)).isDeclared;
    }

    /**
     * @see org.xml.sax.ext.Attributes2#isDeclared(java.lang.String)
     */
    public boolean isDeclared(String name) {
      boolean value = false;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(name, attr.qName)) {
          value = attr.isDeclared;
          break;
        }
      }

      return value;    
    }

    /**
     * @see org.xml.sax.ext.Attributes2#isDeclared(java.lang.String, java.lang.String)
     */
    public boolean isDeclared(String uri, String localName) {
      boolean value = false;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(uri, attr.uri) && areStringEqual(localName, attr.localName)) {
          value = attr.isDeclared;
          break;
        }
      }
      return value;    
    }

    /**
     * @see org.xml.sax.ext.Attributes2#isSpecified(int)
     */
    public boolean isSpecified(int index) {
      return ((Attribute) attrs.get(index)).isSpecified;
    }

    /**
     * @see org.xml.sax.ext.Attributes2#isSpecified(java.lang.String)
     */
    public boolean isSpecified(String name) {
      boolean value = true;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(name, attr.qName)) {
          value = attr.isSpecified;
          break;
        }
      }
      return value;    
    }

    /**
     * @see org.xml.sax.ext.Attributes2#isSpecified(java.lang.String, java.lang.String)
     */
    public boolean isSpecified(String uri, String localName) {
      boolean value = true;
      for (Iterator iterator = attrs.iterator(); iterator.hasNext();) {
        Attribute attr = (Attribute) iterator.next();
        if (areStringEqual(uri, attr.uri) && areStringEqual(localName, attr.localName)) {
          value = attr.isSpecified;
          break;
        }
      }
      return value;    
    }
  }
}