/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.id;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import ro.sync.ecss.extensions.commons.ui.OKCancelDialog;

/**
 * Dialog used to customize DITA elements which have auto ID generation.
 * It is used on standalone implementation.
 */
public class SAIDElementsCustomizerDialog extends OKCancelDialog {
  
  /**
   * The list model.
   */
  private DefaultListModel listModel = new DefaultListModel();
  
  /**
   * The list of elements or class values for which to generate IDs
   */
  private JList listOfElements = new JList(listModel);
  
  /**
   * Auto assign element IDs
   */
  private JCheckBox autoAssignElementIDs = new JCheckBox("Auto generate ID's for elements");

  /**
   * The panel holding the element list and the buttons.
   */
  private JPanel listPanel;
  
  /**
   * The add button.
   */
  private JButton addButton;

  /**
   * The edit button.
   */
  private JButton editButton;

  /**
   * The remove button.
   */
  private JButton removeButton;

  /**
   * The list message
   */
  private final String listMessage;

  /**
   * The id generation pattern field. 
   */
  private JTextField idGenerationPatternField = new JTextField();
  
  /**
   * Constructor.
   * 
   * @param parentFrame The parent frame.
   * @param listMessage The message label used on the list.
   */
  public SAIDElementsCustomizerDialog(JFrame parentFrame, String listMessage) {
    super(parentFrame, "ID Generation", true);
    //The message depending on the framework
    this.listMessage = listMessage;
    JPanel mainPanel = new JPanel(new BorderLayout());
    
    //Panel holding the auto generate checkbox
    //and the pattern customizer
    JPanel northPanel = new JPanel(new GridBagLayout());
    
    GridBagConstraints constr1 = new GridBagConstraints();
    constr1.gridx = 0;
    constr1.gridy = 0;
    constr1.weightx = 1;
    constr1.weighty = 0;
    constr1.gridwidth = 2;
    constr1.fill = GridBagConstraints.HORIZONTAL;
    //The checkbox to automatically generate IDs
    northPanel.add(autoAssignElementIDs, constr1);
    
    constr1.gridy ++;
    constr1.weightx = 0;
    constr1.gridwidth = 1;
    constr1.fill = GridBagConstraints.NONE;
    constr1.insets = new Insets(2, 5, 2, 2);
    //The Pattern customizer
    northPanel.add(new JLabel("ID Pattern:"), constr1);
    
    constr1.gridx ++;
    constr1.weightx = 1;
    constr1.fill = GridBagConstraints.HORIZONTAL;
    northPanel.add(idGenerationPatternField, constr1);
    mainPanel.add(northPanel, BorderLayout.NORTH);
    
    listPanel = new JPanel(new GridBagLayout());
    listPanel.setBorder(BorderFactory.createTitledBorder(listMessage));
    mainPanel.add(listPanel, BorderLayout.CENTER);
    
    GridBagConstraints constr = new GridBagConstraints();
    constr.gridx = 0;
    constr.gridy = 0;
    constr.fill = GridBagConstraints.BOTH;
    constr.weightx = 1;
    constr.weighty = 1;
    constr.anchor = GridBagConstraints.WEST;
    constr.gridwidth = 3;
    
    //List of element local names
    JScrollPane scrollPane = new JScrollPane(listOfElements);
    scrollPane.setPreferredSize(new Dimension(250, 150));
    listPanel.add(scrollPane, constr);
    
    constr.gridy ++;
    constr.fill = GridBagConstraints.NONE;
    constr.weightx = 0;
    constr.weighty = 0;
    constr.gridwidth = 1;
    constr.insets = new Insets(2, 0, 2, 5);
    
    //Add an element name
    addButton = new JButton(new AbstractAction("Add") {
      public void actionPerformed(ActionEvent e) {
        addNewElement();
      }
    });
    listPanel.add(addButton, constr);

    //Edit an element name
    editButton = new JButton(new AbstractAction("Edit") {
      public void actionPerformed(ActionEvent e) {
        editElement();
      }
    });
    constr.gridx ++;
    listPanel.add(editButton, constr);

    //Remove an element name
    removeButton = new JButton(new AbstractAction("Remove") {
      public void actionPerformed(ActionEvent e) {
        removeElement();
      }
    });
    constr.gridx ++;
    listPanel.add(removeButton, constr);
    
    getContentPane().add(mainPanel, BorderLayout.CENTER);
    
    //Pack
    pack();
    setResizable(true);
    
    //Tooltip for the pattern field
    idGenerationPatternField.setToolTipText(
        GenerateIDElementsInfo.LOCAL_NAME_PATTERN_MACRO + " - " + GenerateIDElementsInfo.LOCAL_NAME_PATTERN_DESCRIPTION + "\n " +
        GenerateIDElementsInfo.UUID_PATTERN_MACRO + " - " + GenerateIDElementsInfo.UUID_PATTERN_DESCRIPTION);
    
    listOfElements.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    listOfElements.addListSelectionListener(new ListSelectionListener(){
      public void valueChanged(ListSelectionEvent e) {
        updateButtonState();
      }
    });
    
    updateButtonState();
  }

  /**
   * Update the buttons state on selection change.
   */
  private void updateButtonState() {
    int selectedIndex = listOfElements.getSelectedIndex();
    boolean selected = selectedIndex != -1;
    
    editButton.setEnabled(selected);
    removeButton.setEnabled(selected);
  }

  /**
   * Add a new element.
   */
  private void addNewElement() {
    String elem = JOptionPane.showInputDialog(
        this, listMessage + ": ", "Add", JOptionPane.PLAIN_MESSAGE);
    if (elem != null) {
      listModel.addElement(elem);
      // Select last element.
      listOfElements.setSelectedIndex(listModel.getSize() - 1);
    }
  }
  
  /**
   * Edit the selected element.
   */
  private void editElement() {
    int selectedIndex = listOfElements.getSelectedIndex();
    if (selectedIndex != -1) {
      String elem = (String) JOptionPane.showInputDialog(
          this, listMessage + ": ", "Edit", JOptionPane.PLAIN_MESSAGE,
          null, null, listModel.get(selectedIndex));
      if (elem != null) {
        listModel.set(selectedIndex, elem);
      }
    }
  }
  
  /**
   * Remove the selected element.
   */
  private void removeElement() {
    int selectedIndex = listOfElements.getSelectedIndex();
    if (selectedIndex != -1) {
      listModel.remove(selectedIndex);
      int size = listModel.getSize();
      if (size > 0) {
        if (selectedIndex < size) {
          listOfElements.setSelectedIndex(selectedIndex);
        } else {
          listOfElements.setSelectedIndex(size - 1);
        }
      }
    }
  }

  /**
   * @param autoIDElementsInfo The initial information
   * @return The new information or null if canceled.
   */
  public GenerateIDElementsInfo showDialog(GenerateIDElementsInfo autoIDElementsInfo) {
    // Select the checkbox
    autoAssignElementIDs.setSelected(autoIDElementsInfo.isAutoGenerateIDs());
    // Set the pattern
    idGenerationPatternField.setText(autoIDElementsInfo.getIdGenerationPattern());
    // Set the data in the list model.
    listModel.clear();
    String[] elements = autoIDElementsInfo.getElementsWithIDGeneration();
    if (elements != null) {
      for (int i = 0; i < elements.length; i++) {
        listModel.addElement(elements[i]);
      }
    }
    updateButtonState();
    
    // Show dialog.
    setVisible(true);
    if(getResult() == RESULT_OK) {
      // OK  pressed.
      String[] elems = new String[listModel.getSize()];
      listModel.copyInto(elems);
      
      return new GenerateIDElementsInfo(
          autoAssignElementIDs.isSelected(),
          idGenerationPatternField.getText(),
          elems);
    }
    return null;
  }
}