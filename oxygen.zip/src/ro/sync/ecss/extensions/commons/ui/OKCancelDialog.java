/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.ui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.KeyStroke;

/** 
 * Dialog with OK and Cancel buttons.
 */
public class OKCancelDialog extends JDialog {

  /**
   * Dialog was canceled.  
   */
  public static final int RESULT_CANCEL = 0;

  /**
   * 'Ok' button was pressed.  
   */
  public static final int RESULT_OK = 1;

  /**
   * The result of the dialog. 
   * If 'Ok' was pressed the dialog data can be questioned, 
   * otherwise does not matter.
   */
  private int result = RESULT_CANCEL;

  /**
   *  The ok button.
   */
  private JButton okButton = new JButton("OK");

  /**
   *  The cancel button.
   */
  private JButton cancelButton = new JButton("Cancel");
  
  /**
   * The content panel
   */
  private JPanel contentPanel = new JPanel(new BorderLayout());

  /**
   * Constructor.
   * 
   * @param parentFrame  The parent frame
   * @param title The dialog title
   * @param modal  True if modal
   */
  public OKCancelDialog(JFrame parentFrame, String title, boolean modal) {
    super(parentFrame, title, modal);

    //Listener for ENTER pressed
    this.getRootPane().registerKeyboardAction(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        if(okButton.isEnabled()) {
          doOK();
        }
      }
    }, KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), JComponent.WHEN_IN_FOCUSED_WINDOW);

    addKeyListener(new KeyAdapter() {
      @Override
      public void keyTyped(KeyEvent e) {
        if (e.getKeyChar() == '\n') {
          if(okButton.isEnabled()) {
            doOK();
          }
        }
      }
    });
    //For tests
    okButton.setName("Ok button");
    //The OK button
    getRootPane().setDefaultButton(okButton);
    
    //Listener for ESC pressed
    AbstractAction cancelAction = new AbstractAction() {
      public void actionPerformed(ActionEvent e) {
        if(cancelButton.isEnabled()) {
          doCancel();
        }
      }
    };
    getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(
        KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), cancelAction);
    getRootPane().getActionMap().put(cancelAction, cancelAction);


    JPanel mainPanel = new JPanel(new GridBagLayout());
    mainPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    GridBagConstraints gridBagConstr = new GridBagConstraints();
    gridBagConstr.gridx = 0;
    gridBagConstr.gridy = 0;
    gridBagConstr.fill = GridBagConstraints.BOTH;
    gridBagConstr.weightx = 1;
    gridBagConstr.weighty = 1;
    gridBagConstr.anchor = GridBagConstraints.WEST;
    gridBagConstr.gridwidth = 2;
    mainPanel.add(contentPanel, gridBagConstr);

    // Control buttons panel
    JPanel controlButtonsPanel = new JPanel(new BorderLayout());
    okButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doOK();
      }
    });
    cancelButton.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        doCancel();
      }
    });
    controlButtonsPanel.add(okButton, isMacOSX() ? BorderLayout.EAST : BorderLayout.WEST);
    controlButtonsPanel.add(cancelButton, isMacOSX() ? BorderLayout.WEST : BorderLayout.EAST);

    gridBagConstr.gridx = 0;
    gridBagConstr.gridy++;
    gridBagConstr.gridwidth = 2;
    gridBagConstr.weightx = 1;
    gridBagConstr.weighty = 0;
    gridBagConstr.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstr.insets = new Insets(5, 0, 0, 0);
    mainPanel.add(controlButtonsPanel, gridBagConstr);

    setContentPane(mainPanel);

    pack();
    setResizable(false);
  }

  /**
   * OK pressed.
   */
  protected void doOK() {
    result = RESULT_OK;
    setVisible(false);
  }

  /**
   * Cancel pressed.
   */
  protected void doCancel() {
    result = RESULT_CANCEL;
    setVisible(false);
  }

  /**
   * Gets the result of the the dialog. Used after show.
   *
   * @return The result value.
   */
  public int getResult() {
    return result;
  }

  /**
   *  Sets the text on the ok button.
   *
   *@param  text  The text value.
   */
  public void setOkButtonText(String text) {
    okButton.setText(text);
  }

  /**
   *  Sets the text on the cancel button.
   *
   *@param  text  The text value.
   */
  public void setCancelButtonText(String text) {
    cancelButton.setText(text);
  }

  /**
   * @return true if we are running on MAC OSX
   */
  private boolean isMacOSX() {
    if (System.getProperty("os.name").toUpperCase().startsWith("MAC OS")) {
      return true;
    }
    return false;
  }
  
  /**
   * @see javax.swing.JDialog#getContentPane()
   */
  @Override
  public Container getContentPane() {
    return contentPanel;
  }
}
