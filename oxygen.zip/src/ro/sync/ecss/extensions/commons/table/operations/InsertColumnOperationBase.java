/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.table.operations;

import javax.swing.text.BadLocationException;

import ro.sync.ecss.extensions.api.ArgumentDescriptor;
import ro.sync.ecss.extensions.api.ArgumentsMap;
import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.AuthorOperationException;
import ro.sync.ecss.extensions.api.AuthorTableCellSpanProvider;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Operation used to insert a table column.
 */
public abstract class InsertColumnOperationBase extends AbstractTableOperation {
  
  /**
   * Constructor.
   * 
   * @param documentTypeHelper Document type helper, has methods specific to a 
   * document type.
   */
  public InsertColumnOperationBase(AuthorTableHelper documentTypeHelper) {
    super(documentTypeHelper);
  }

  /**
   * Arguments.
   */
  private static final ArgumentDescriptor[] ARGUMENTS = 
    new ArgumentDescriptor[] { NAMESPACE_ARGUMENT_DESCRIPTOR };
  
  /**
   * @see ro.sync.ecss.extensions.api.AuthorOperation#doOperation(ro.sync.ecss.extensions.api.AuthorAccess, ro.sync.ecss.extensions.api.ArgumentsMap)
   */
  public void doOperation(AuthorAccess authorAccess, ArgumentsMap args)
      throws IllegalArgumentException, AuthorOperationException {
    try {
      // Find the index where the new column will be inserted
      int newColumnIndex = -1;
      
      int caretOffset = authorAccess.getEditorAccess().getCaretOffset();
      AuthorNode nodeAtCaret = authorAccess.getDocumentController().getNodeAtOffset(caretOffset);
      
      // Find the table element to create table span support
      AuthorElement tableElement = getElementAncestor(
          nodeAtCaret, AuthorTableHelper.TYPE_TABLE);
      if (tableElement != null) {
        // Create the table support
        AuthorTableCellSpanProvider tableSupport = 
          tableHelper.getTableCellSpanProvider(tableElement);
        if (isTableElement(nodeAtCaret, AuthorTableHelper.TYPE_ROW)) {
          // The caret is inside a table row. 
          // Try to find the insertion index analyzing the left and right cell column index
          newColumnIndex = findColumnIndex(authorAccess, caretOffset + 1);
          if (newColumnIndex == -1) {
            // No cell after, try to find a cell before
            newColumnIndex = findColumnIndex(authorAccess, caretOffset - 1);
            if (newColumnIndex != -1) {
              // Insert after left column
              newColumnIndex ++;
            } else {
              // There are no neighboring cells, use the first column
              newColumnIndex = 0;
            }
          }
        } else {
          // The caret is not inside a table row. Find the nearest table cell that include the caret
          AuthorElement cell = getElementAncestor(nodeAtCaret, AuthorTableHelper.TYPE_CELL);
          if (cell != null) {
            int[] cellIndex = authorAccess.getTableAccess().getTableCellIndex(cell);
            if (cellIndex != null) {
              Integer colSpan = tableSupport.getColSpan(cell);
              newColumnIndex = cellIndex[1] + (colSpan != null ? colSpan.intValue() : 1);
            } else {            
              throw new AuthorOperationException(
                  "Cannot obtain the index of cell in table. The cell is: " + cell);
            }
          } else {
            throw new AuthorOperationException(
            "Cannot find a cell in the table at the current caret position.");
          }
        }


        String namespace = null;
        Object namespaceObj =  args.getArgumentValue(NAMESPACE_ARGUMENT);
        if (namespaceObj instanceof String) {
          namespace = (String) namespaceObj;
        }

        // The current number of columns 
        int numberOfColumns = authorAccess.getTableAccess().getTableNumberOfColumns(tableElement);

        // Update the column specification for the table only if the table is empty or it already 
        // contains some column specifications.
        if (authorAccess.getTableAccess().getTableNumberOfColumns(tableElement) == 0 ||
            tableSupport.hasColumnSpecifications(tableElement)) {
          updateColumnCellsSpan(
              authorAccess, tableSupport, tableElement, newColumnIndex, namespace);
        }

        // Insert the new entries in the rows in the appropriate places
        insertNewColumnCells(authorAccess, tableSupport, tableElement, newColumnIndex, namespace);

        tableHelper.updateTableColumnNumber(
            authorAccess, 
            tableElement,
            numberOfColumns + 1);
      } 
      
    } catch (BadLocationException e) {
      throw new AuthorOperationException(
          "The operation cannot be performed due to: " + e.getMessage(), 
          e);
    }
  }

  /**
   * Increments the column span of the cells intersecting the new column.
   * A cell intersects the column to insert if its start column index is less than
   * the new column index and the end column index of the cell is greater or equal
   * than the new column ((startColSpan < newColumnIndex) && (endColSpan >= newColumnIndex)).
   * 
   * @param authorAccess The author access.
   * Provides access to specific informations and actions for 
   * editor, document, workspace, tables, change tracking, utility a.s.o.
   * @param tableSupport The table cell span provider.
   * @param tableElem    The table element.
   * @param newColumnIndex The index of the column to insert.
   * @param namespace    The namespace to be used.
   * @throws AuthorOperationException  When the insertion fails.
   */
  protected void updateColumnCellsSpan(
      AuthorAccess authorAccess, 
      AuthorTableCellSpanProvider tableSupport,
      AuthorElement tableElem,
      int newColumnIndex,
      String namespace) throws AuthorOperationException {
    
    int rowCount = authorAccess.getTableAccess().getTableRowCount(tableElem);
    if (newColumnIndex > 0) {
      if (rowCount != -1) {
        AuthorElement prevCell = null;
        // For each row from end to start
        for (int i = rowCount - 1; i >=0; i--) {
          // Check if there is a cell at the column where the insertion will occur
          AuthorElement cell = authorAccess.getTableAccess().getTableCellAt(i, newColumnIndex, tableElem);
          if(prevCell == cell) {
            continue;
          }
          prevCell = cell;
          if (cell != null) {
            int[] cellIndices = authorAccess.getTableAccess().getTableColSpanIndices(cell);
            int colSpanStart = cellIndices[0];
            int colSpanEnd = cellIndices[1];
            if (colSpanStart < newColumnIndex && newColumnIndex <= colSpanEnd) {
              // The cell spans over the added column, adjust its column span
              tableHelper.updateTableColSpan(
                  authorAccess,
                  tableSupport,
                  cell,
                  colSpanStart + 1, // adjust for 1 base
                  colSpanEnd + 2); // adjust for 1 base + increment
            }
          }
        }
      }
    }
  }

  /**
   * Insert the cells for the new column.
   * 
   * @param authorAccess The author access.
   * Provides access to specific informations and actions for 
   * editor, document, workspace, tables, change tracking, utility a.s.o.
   * @param tableSupport The table cell span provider.
   * @param tableElement The table element.
   * @param newColumnIndex The column index, 0 based.
   * @param namespace The namespace to be used.
   * 
   * @throws AuthorOperationException 
   */
  private void insertNewColumnCells(
      AuthorAccess authorAccess,
      AuthorTableCellSpanProvider tableSupport,
      AuthorElement tableElement,
      int newColumnIndex,
      String namespace) throws AuthorOperationException {
    
    int insertionOffset = -1;
    int rowCount = authorAccess.getTableAccess().getTableRowCount(tableElement);
    if (rowCount != -1) {
      int caretOffset = -1;
      String[] elementNames = new String[rowCount];
      int[] offsets = new int[rowCount];
      for (int i = 0; i < rowCount; i++) {
        offsets[i] = -1;
        // For each row from end to start
        if (newColumnIndex > 0) {          
          // Check if there is a cell at the column where the insertion will occur
          AuthorElement cell = authorAccess.getTableAccess().getTableCellAt(i, newColumnIndex, tableElement);
          if (cell != null) {
            // Is an insertion necessary? 
            int[] cellIndices = authorAccess.getTableAccess().getTableColSpanIndices(cell);
            int colSpanStart = cellIndices[0];
            int colSpanEnd = cellIndices[1];
            if (colSpanStart < newColumnIndex && newColumnIndex <= colSpanEnd) {
              // Skip to the next row
              continue;
            }
          }
          
          // Check if there is a cell to the left of the location where the insertion should occur
          cell = authorAccess.getTableAccess().getTableCellAt(i, newColumnIndex - 1, tableElement);
          if (cell == null) {
            // If there's no cell then skip to the next row
            continue;
          }
        }
        // Find the insertion offset (after the closest cell in the row starting from the left)
        insertionOffset = findCellInsertionOffset(authorAccess, tableElement, i, newColumnIndex);
        
        if (insertionOffset != -1) {
          offsets[i] = insertionOffset;
          elementNames[i] = getCellElementName(authorAccess.getTableAccess().getTableRow(i, tableElement), newColumnIndex);
          if (elementNames[i] == null) {
            throw new AuthorOperationException("The table model does not accept a new column at the given position.");
          }
          if (caretOffset == -1) {
            // Keep the first insertion offset to set the caret after the operation is performed.
            caretOffset = insertionOffset;
          }
        }
      }
      authorAccess.getDocumentController().insertMultipleElements(tableElement, elementNames, offsets, namespace);
      // Set the caret inside the first cell(we know is an empty element).
      authorAccess.getEditorAccess().setCaretPosition(caretOffset + 1);
    } else {
      throw new AuthorOperationException(
          "Could not obtain the number of rows. Table is invalid.");
    }
  }

  /**
   * Find the column index of the cell at the specified offset.
   * 
   * @param authorAccess The author access.
   * Provides access to specific informations and actions for 
   * editor, document, workspace, tables, change tracking, utility a.s.o.
   * @param offset The offset of the searched column.
   * @return The index of the column at offset (0 based).
   * @throws BadLocationException
   * @throws AuthorOperationException
   */
  private int findColumnIndex(AuthorAccess authorAccess, int offset)
      throws BadLocationException, AuthorOperationException {
    int newColumnIndex = -1;
    // The caret is inside a table row
    AuthorNode relativeCell = 
      authorAccess.getDocumentController().getNodeAtOffset(offset);
    if (isTableElement(relativeCell, AuthorTableHelper.TYPE_CELL)) {
      int[] cellIndex = authorAccess.getTableAccess().getTableCellIndex((AuthorElement) relativeCell);
      if (cellIndex != null) {
        newColumnIndex = cellIndex[1];
      } else {            
        throw new AuthorOperationException(
            "Cannot obtain the index of cell in table. The cell is: " + relativeCell);
      }
    }
    return newColumnIndex;
  }
  
  /**
   * @see ro.sync.ecss.extensions.api.AuthorOperation#getArguments()
   */
  public ArgumentDescriptor[] getArguments() {
    return ARGUMENTS;
  }

  /**
   * Get the description for this operation.
   * 
   * @see ro.sync.ecss.extensions.api.Extension#getDescription()
   */
  public String getDescription() {
    return "Insert a table column.";
  }
  
  //////////////////////////////
  //////// Abstract methods
  
  /**
   * Get the name of the element that will be inserted as a cell into the table.
   * 
   * @param rowElement The row element where the new cell will be inserted. 
   * @param newColumnIndex The new column index. 0 based.
   * @return The name of cell element.
   */
  protected abstract String getCellElementName(AuthorElement rowElement, int newColumnIndex);
}