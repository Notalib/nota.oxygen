/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.table.operations;

import org.eclipse.jface.dialogs.Dialog;
import org.eclipse.swt.SWT;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionAdapter;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Control;
import org.eclipse.swt.widgets.Group;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.swt.widgets.Spinner;
import org.eclipse.swt.widgets.Text;

import ro.sync.xml.XmlUtil;

/**
 * Dialog used to customize the insertion of a generic table (number of rows, columns, table caption).
 * It is used on Eclipse platform implementation.
 */
public abstract class ECTableCustomizerDialog extends Dialog implements TableCustomizerConstants{
  
  /**
   * If create a title the user can specify the table title.
   */
  private String title;

  /**
   * Set a title to the table.
   */
  private boolean createTitle;

  /**
   * For specify the number of rows.
   */
  private int rows;

  /**
   * Specify the number of columns.
   */
  private int columns;
  /**
   * If <code>true</code> an empty table header will be generated.
   */
  private boolean createHeader;
  /**
   * If <code>true</code> an empty table footer will be generated.
   */
  private boolean createFooter;

  /**
   * True to make CALS table.
   */
  private boolean makeCalsTable;
  
  /**
   * The selected frame.
   */
  private String selectedFrame;
  
  //Customization parameters.
  /**
   * The table that is customized by this dialog has a footer.
   */
  private final boolean hasFooter;
  
  /**
   * The table customized by this dialog has a frame attribute.
   */
  private final boolean hasFrameAttribute;
  
  /**
   * The table can be of any one of the types: CALS or HTML.
   */
  private final boolean showModelChooser;

  /**
   * The title text field.
   */
  private Text titleTextField;

  /**
   * Frame values combo.
   */
  private Combo framesCombo;

  /**
   * The table can be have a simple model.
   */
  private final boolean simpleTableModel;

  /**
   * The title checkbox.
   */
  private Button titleCheckbox;
  
  /**
   * Constructor for TrangDialog.
   * 
   * @param parentShell The parent shell for the dialog.
   * @param hasFooter If this table supports a footer.
   * @param hasFrameAttribute If the table has a frame attribute.
   * @param showModelChooser If true then show the dialog panel for choosing the table model, 
   * one of CALS or HTML.
   */
  public ECTableCustomizerDialog(
      Shell parentShell, boolean hasFooter, boolean hasFrameAttribute,
      boolean showModelChooser) {
    this(parentShell, hasFooter, hasFrameAttribute, showModelChooser, false);
  }

  /**
   * Constructor for TrangDialog.
   * 
   * @param parentShell The parent shell for the dialog.
   * @param hasFooter If this table supports a footer.
   * @param hasFrameAttribute If the table has a frame attribute.
   * @param showModelChooser If true then show the dialog panel for choosing the table model, 
   * one of CALS or HTML.
   * @param showSimpleModel If true then show the simple model radio in
   * the model chooser.
   */
  public ECTableCustomizerDialog(
      Shell parentShell, boolean hasFooter, boolean hasFrameAttribute,
      boolean showModelChooser, boolean showSimpleModel) {
    super(parentShell);
    this.hasFooter = hasFooter;
    this.hasFrameAttribute = hasFrameAttribute;
    this.showModelChooser = showModelChooser;
    this.simpleTableModel = showSimpleModel;
  }

  /**
   * Configure Shell. Set a title to it.
   * 
   * @param newShell The new shell.
   * @see org.eclipse.jface.dialogs.Dialog#configureShell(org.eclipse.swt.widgets.Shell)
   */
  @Override
  protected void configureShell(Shell newShell) {
    newShell.setText("Insert Table");
    super.configureShell(newShell);
  }

  /**
   * Create Dialog area.
   * 
   * @param parent The parent composite.
   * @return The dialog control.
   */
  @Override
  protected Control createDialogArea(Composite parent) {
    Composite composite = (Composite) super.createDialogArea(parent);
    composite.setLayout(new GridLayout(2, false));
    
    if (showModelChooser) {
      //Allow the user to choose between HTML and CALS
      Group modelChooser = new Group(composite, SWT.SINGLE);
      modelChooser.setText("Model");
      modelChooser.setLayout(new GridLayout(2, true));
      GridData data = new GridData(SWT.FILL, SWT.NONE, true, false);
      data.horizontalSpan = 2;
      modelChooser.setLayoutData(data);
      
      // Radio button for choosing CALS table model
      final Button calsModelRadio = new Button(modelChooser, SWT.RADIO | SWT.LEFT);
      calsModelRadio.setText("CALS");
      calsModelRadio.addSelectionListener(new SelectionAdapter() {
        @Override
        public void widgetSelected(SelectionEvent e) {
          makeCalsTable = calsModelRadio.getSelection();
          framesCombo.setItems(getFrameValues(TableInfo.TABLE_MODEL_CALS));
          framesCombo.setText(framesCombo.getItem(0));
          updateTitleState(true);
        }
      });

      if (simpleTableModel) {
        // Radio button for choosing simple table model
        Button simpleTableModelRadio = new Button(modelChooser, SWT.RADIO | SWT.LEFT);
        simpleTableModelRadio.setText("Simple");
        simpleTableModelRadio.addSelectionListener(new SelectionAdapter() {
          @Override
          public void widgetSelected(SelectionEvent e) {
            makeCalsTable = calsModelRadio.getSelection();;
            framesCombo.setItems(getFrameValues(TableInfo.TABLE_MODEL_DITA_SIMPLE));
            framesCombo.setText(framesCombo.getItem(0));
            updateTitleState(false);
          }
        });

        //Set some default values.
        makeCalsTable = true;
        calsModelRadio.setSelection(true);
        simpleTableModelRadio.setSelection(false);
      } else {
        // Radio button for choosing HTML table model
        Button htmlModelRadio = new Button(modelChooser, SWT.RADIO | SWT.LEFT);
        htmlModelRadio.setText("HTML");
        htmlModelRadio.addSelectionListener(new SelectionAdapter() {
          @Override
          public void widgetSelected(SelectionEvent e) {
            makeCalsTable = calsModelRadio.getSelection();;
            framesCombo.setItems(getFrameValues(TableInfo.TABLE_MODEL_HTML));
            framesCombo.setText(framesCombo.getItem(0));
          }
        });

        //Set some default values.
        makeCalsTable = true;
        calsModelRadio.setSelection(true);
        htmlModelRadio.setSelection(false);
      }
    }

    // Title check box.
    titleCheckbox = createTitleCheckbox(composite);
    titleCheckbox.addSelectionListener(new SelectionAdapter() {
      @Override
      public void widgetSelected(SelectionEvent e) {
        titleTextField.setEditable(titleCheckbox.getSelection());
        createTitle = titleCheckbox.getSelection();
      }
    });
    //Set some default values.
    titleCheckbox.setSelection(true);
    createTitle = true;
    
    // Title text field
    titleTextField = new Text(composite, SWT.SINGLE | SWT.BORDER);
    titleTextField.addModifyListener(new ModifyListener() {
      public void modifyText(ModifyEvent e) {
        title = titleTextField.getText();
      }
    });
    GridData data = new GridData(SWT.FILL, SWT.NONE, true, false);
    titleTextField.setLayoutData(data);
    titleTextField.setFocus();
    //Set some default values.
    title = "";

    //Give the number of rows and cols for the new table.
    Group sizeGroup = new Group(composite, SWT.SINGLE);
    sizeGroup.setText("Table Size");
    sizeGroup.setLayout(new GridLayout(4, false));
    data = new GridData(SWT.FILL, SWT.NONE, true, false);
    data.horizontalSpan = 2;
    sizeGroup.setLayoutData(data);

    // 'Rows' label.
    Label label = new Label(sizeGroup, SWT.LEFT);
    label.setText("Rows");
    final Spinner rowsSpinner = new Spinner(sizeGroup, SWT.BORDER);
    rowsSpinner.setMinimum(0);
    rowsSpinner.setMaximum(100);
    rowsSpinner.setSelection(3);
    rowsSpinner.addModifyListener(new ModifyListener() {
      public void modifyText(ModifyEvent e) {
        rows = rowsSpinner.getSelection();
      }
    });
    rowsSpinner.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));
    //Set some default values.
    rows = 3;

    // 'Columns' label
    label = new Label(sizeGroup, SWT.LEFT);
    label.setText("Columns");
    final Spinner columnsSpinner = new Spinner(sizeGroup, SWT.BORDER);
    columnsSpinner.setMinimum(0);
    columnsSpinner.setMaximum(100);
    columnsSpinner.setSelection(2);
    columnsSpinner.addModifyListener(new ModifyListener() {
      public void modifyText(ModifyEvent e) {
        columns = columnsSpinner.getSelection();
      }
    });
    columnsSpinner.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));
    //Set some default values.
    columns = 2;

    //Allow header and/or footer generation.
    Composite headerAndFooterComposite = new Composite(composite, SWT.NONE);
    GridLayout layout = new GridLayout(2, true);
    layout.marginHeight = 0;
    layout.marginWidth = 0;
    headerAndFooterComposite.setLayout(layout);
    data = new GridData(SWT.FILL, SWT.FILL, true, true);
    data.horizontalSpan = 2;
    headerAndFooterComposite.setLayoutData(data);

    // 'Header' check box
    final Button headerCheckbox = new Button(headerAndFooterComposite, SWT.CHECK | SWT.LEFT);
    headerCheckbox.setText("Generate table header");
    headerCheckbox.addSelectionListener(new SelectionAdapter() {
      @Override
      public void widgetSelected(SelectionEvent e) {
        createHeader = headerCheckbox.getSelection();
      }
    });
    //Set some default values.
    headerCheckbox.setSelection(true);
    createHeader = true;

    if (hasFooter) {
      // 'Footer' check box
      final Button footerCheckbox = new Button(headerAndFooterComposite, SWT.CHECK | SWT.LEFT);
      footerCheckbox.setText("Generate table footer");
      footerCheckbox.addSelectionListener(new SelectionAdapter() {
        @Override
        public void widgetSelected(SelectionEvent e) {
          createFooter = footerCheckbox.getSelection();
        }
      });
      //Set some default values.
      footerCheckbox.setSelection(false);
      createFooter = false;
    }

    if (hasFrameAttribute) {
      // 'Frame' label.
      Label frameLabel = new Label(composite, SWT.LEFT);
      frameLabel.setText("Frame");

      // Frame combo box
      framesCombo = new Combo(composite, SWT.DROP_DOWN | SWT.READ_ONLY);
      framesCombo.setItems(getFrameValues(getTableModel()));
      framesCombo.setText(framesCombo.getItem(0));
      framesCombo.addSelectionListener(new SelectionAdapter() {
        @Override
        public void widgetSelected(SelectionEvent e) {
          selectedFrame = framesCombo.getText();
        }
      });
      framesCombo.setLayoutData(new GridData(SWT.FILL, SWT.NONE, true, false));
      selectedFrame = framesCombo.getText();
    }
    
    return composite;
  }

  /**
   * Compute the possible values for <code>'frame'</code> attribute.
   * 
   * @param tableModel The table model. 
   * One of the constants: 
   * {@link TableInfo#TABLE_MODEL_CALS}, {@link TableInfo#TABLE_MODEL_CUSTOM},
   * {@link TableInfo#TABLE_MODEL_DITA_SIMPLE}, {@link TableInfo#TABLE_MODEL_HTML}.
   * @return Returns the possible values for <code>'frame'</code> attribute. 
   */
  protected abstract String[] getFrameValues(int tableModel);

  /**
   * Create a checkbox with an implementation specific title.
   * 
   * @param parent The parent {@link Composite}.
   * @return The title checkbox customized according to implementation.
   */
  protected abstract Button createTitleCheckbox(Composite parent);

  /**
   * Show the dialog to customize the table attributes.
   * 
   * @return The information about the table to be inserted, 
   * or <code>null</code> if the user canceled the table insertion.
   */
  public TableInfo showDialog() {
    if (OK == open()) {
      // Compute the value of the table model
      int tableModel = getTableModel();
      // EXM-11910 Escape the table title.
      title = XmlUtil.escape(title);
      return 
      new TableInfo(
          createTitle ? title : null, 
          rows, 
          columns, 
          createHeader, 
          hasFooter? createFooter : false, 
              hasFrameAttribute ? selectedFrame : null,
                  tableModel);
    } else {
      // Cancel was pressed
    }
    return null;
  }

  /**
   * @return The table model depending on the state of the dialog.
   * One of the constants: 
   * {@link TableInfo#TABLE_MODEL_CALS}, {@link TableInfo#TABLE_MODEL_CUSTOM},
   * {@link TableInfo#TABLE_MODEL_DITA_SIMPLE}, {@link TableInfo#TABLE_MODEL_HTML}.
   */
  private int getTableModel() {
    int tableModel = TableInfo.TABLE_MODEL_CUSTOM;
    if (showModelChooser) {
      if (makeCalsTable) {
        tableModel = TableInfo.TABLE_MODEL_CALS;
      } else {
        if (simpleTableModel) {
          tableModel = TableInfo.TABLE_MODEL_DITA_SIMPLE;
        } else {
          tableModel = TableInfo.TABLE_MODEL_HTML;
        }
      }
    }
    return tableModel;
  }
  
  /**
   * Update the state of the title section.
   * 
   * @param enabled <code>true</code> if the title section is enabled.
   */
  private void updateTitleState(boolean enabled) {
    titleCheckbox.setEnabled(enabled);
    titleTextField.setEditable(enabled && titleCheckbox.getSelection());
  }
}