/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.table.operations;

import javax.swing.text.BadLocationException;

import ro.sync.ecss.extensions.api.ArgumentDescriptor;
import ro.sync.ecss.extensions.api.ArgumentsMap;
import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.AuthorConstants;
import ro.sync.ecss.extensions.api.AuthorOperationException;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Abstract class for operation used to insert a table row. 
 */
public abstract class InsertRowOperationBase extends AbstractTableOperation {
  
  /**
   * The insert location argument.
   * The value is <code>insertLocation</code>
   */
  private static final String ARGUMENT_XPATH_LOCATION = "insertLocation";
  
  /**
   * The insert position argument.
   *  The value is <code>insertPosition</code>
   */
  private static final String ARGUMENT_RELATIVE_LOCATION = "insertPosition";

  /**
   * The arguments of the operation.
   */
  private ArgumentDescriptor[] arguments = null;
  
  /**
   * Get the array of arguments used for this operation.
   * The first argument define the location where the operation will be executed
   * as an xpath expression, the second one define the relative position to the 
   * node obtained from the XPath location and the third is the namespace argument
   * descriptor.
   * For the second argument included in the returned arguments descriptor array,
   * the allowed values are:
   * <code>
   * {@link AuthorConstants#POSITION_BEFORE}, 
   * {@link AuthorConstants#POSITION_AFTER}, 
   * {@link AuthorConstants#POSITION_INSIDE}
   * </code> 
   * 
   * @return The array with the arguments of the operation.
   */
  protected ArgumentDescriptor[] getOperationArguments() {
    ArgumentDescriptor[] args = new ArgumentDescriptor[3];
    
    // Argument defining the location where the operation will be executed as an xpath expression
    ArgumentDescriptor argumentDescriptor = 
      new ArgumentDescriptor(
          ARGUMENT_XPATH_LOCATION, 
          ArgumentDescriptor.TYPE_XPATH_EXPRESSION, 
          "An XPath expression indicating the insert location for the new table row.\n" +
          "Note: If it is not defined then the insert location will be at the caret.");
    args[0] = argumentDescriptor;
    
    // Argument defining the relative position to the node obtained from the XPath location
    argumentDescriptor = 
      new ArgumentDescriptor(
          ARGUMENT_RELATIVE_LOCATION, 
          ArgumentDescriptor.TYPE_CONSTANT_LIST,
          "The insert position relative to the node determined by the XPath expression.\n" +
          "Can be: Inside, Before, After.\n" +
          "Note: If the XPath expression is not defined this argument is ignored.",
          new String[] {
              AuthorConstants.POSITION_INSIDE,
              AuthorConstants.POSITION_BEFORE,
              AuthorConstants.POSITION_AFTER,
          }, 
          AuthorConstants.POSITION_INSIDE);
    args[1] = argumentDescriptor;
    
    args[2] = NAMESPACE_ARGUMENT_DESCRIPTOR;
    return args;
  }
  
  /**
   * Constructor.
   * 
   * @param documentTypeHelper Author Document type helper, has methods specific to a document type.
   */
  public InsertRowOperationBase(AuthorTableHelper documentTypeHelper) {
    super(documentTypeHelper);
    
    arguments = getOperationArguments();
  }
    
  /**
   * @see ro.sync.ecss.extensions.api.AuthorOperation#doOperation(ro.sync.ecss.extensions.api.AuthorAccess, ro.sync.ecss.extensions.api.ArgumentsMap)
   */
  public void doOperation(AuthorAccess authorAccess, ArgumentsMap args)
  throws IllegalArgumentException, AuthorOperationException {
    try {
      Object namespaceObj =  args.getArgumentValue(NAMESPACE_ARGUMENT);
      String xmlFragment = getRowXMLFragment(authorAccess, (String) namespaceObj);
      if (xmlFragment != null) {
        authorAccess.getDocumentController().insertXMLFragment(
            xmlFragment, 
            (String)args.getArgumentValue(ARGUMENT_XPATH_LOCATION), 
            (String)args.getArgumentValue(ARGUMENT_RELATIVE_LOCATION));
      }
    } catch (BadLocationException e) {
      throw new AuthorOperationException(
          "The operation cannot be performed due to: " + e.getMessage(), 
          e);    
    }    
  }

  /**
   * Create the XML fragment representing the new table row to be inserted.
   * 
   * @param namespace The namespace of the table row.
   * @return  The XML fragment to be inserted.
   * 
   * @throws BadLocationException  
   */
  private String getRowXMLFragment(
      AuthorAccess authorAccess, 
      String namespace) throws BadLocationException {
    StringBuffer stringBuffer = null;
    AuthorNode nodeAtCaret = authorAccess.getDocumentController().getNodeAtOffset(
        authorAccess.getEditorAccess().getCaretOffset());    
    AuthorElement tableElement = getElementAncestor(
        nodeAtCaret, AuthorTableHelper.TYPE_TABLE);
    if(tableElement != null) {
      String rowName = getRowElementName(tableElement);
      if (rowName != null) {
        stringBuffer = new StringBuffer("<" + rowName + "");

        if(namespace != null) {
          stringBuffer.append(" xmlns=\"" + namespace + "\"");
        }
        stringBuffer.append(">");

        int colsNumber = authorAccess.getTableAccess().getTableNumberOfColumns(tableElement);
        for (int i = 0; i < colsNumber; i++) {
          String cellName = getCellElementName(tableElement, i);
          if (cellName != null) {
            stringBuffer.append("<" + cellName + "/>");
          }
        }

        stringBuffer.append("</" + rowName + ">");
      }
    }
    return stringBuffer == null ? null : stringBuffer.toString();
  }
  
  /**
   * The operation will display a dialog for choose table attributes.
   * 
   * @see ro.sync.ecss.extensions.api.AuthorOperation#getArguments()
   */
  public ArgumentDescriptor[] getArguments() {
    return arguments;
  }
  
  /**
   * @see ro.sync.ecss.extensions.api.Extension#getDescription()
   */
  public String getDescription() {
    return "Insert a table row.";
  }

  /**
   * Get the name of the element that represents a cell.
   * @param tableElement The table element
   * @param columnIndex The column index.
   * @return The name of the element that represent a cell in the table.
   */
  protected abstract String getCellElementName(AuthorElement tableElement, int columnIndex);

  /**
   * Get the name of the element that represents a row.
   * 
   * @param tableElement The table parent element.
   * @return The name of the element that represent a row in the table.
   */
  protected abstract String getRowElementName(AuthorElement tableElement);
}