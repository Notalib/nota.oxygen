/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.table.operations.cals;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.AuthorOperationException;
import ro.sync.ecss.extensions.api.AuthorTableCellSpanProvider;
import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.ecss.extensions.commons.table.operations.InsertColumnOperationBase;
import ro.sync.ecss.extensions.commons.table.support.CALSColSpec;
import ro.sync.ecss.extensions.commons.table.support.CALSTableCellInfoProvider;

/**
 * Operation used to insert a CALS table column.
 */
public class InsertColumnOperation extends InsertColumnOperationBase implements CALSConstants {
  
  /**
   * Constructor.
   */
  public InsertColumnOperation() {
    super(new CALSDocumentTypeHelper());
  }

  /**
   * Overwrite the base implementation.
   * For CALS tables the column specifications must be updated. 
   * 
   * @see ro.sync.ecss.extensions.commons.table.operations.InsertColumnOperationBase#updateColumnCellsSpan(ro.sync.ecss.extensions.api.AuthorAccess, ro.sync.ecss.extensions.api.AuthorTableCellSpanProvider, ro.sync.ecss.extensions.api.node.AuthorElement, int, java.lang.String)
   */
  @Override
  protected void updateColumnCellsSpan(AuthorAccess authorAccess,
      AuthorTableCellSpanProvider tableSupport, AuthorElement tgroup, int newColumnIndex,
      String namespace) throws AuthorOperationException {
    
    // Find the name of the column specification relative to which the insertion will be performed. 
    Set<CALSColSpec> colSpecs = ((CALSTableCellInfoProvider) tableSupport).getColSpecs();
    
    String relativeColSpecName = null;
    // If true insert the new 'colspec' before the determined relative 'colspec'
    boolean insertBefore = false; 
    for (Iterator iterator = colSpecs.iterator(); iterator.hasNext();) {
      CALSColSpec colSpec = (CALSColSpec) iterator.next();
      relativeColSpecName = colSpec.getColumnName();
      if(colSpec.getColumnNumber() >= newColumnIndex + 1) {
        insertBefore = true;
        break;
      }
    }
    
    // Determine the index in document where the new 'colspec' will be inserted
    int insertOffset = -1;
    if(relativeColSpecName != null) {
      // Increase the 'colnum' attributes which are <= than the inserted column
      List contentNodes = tgroup.getContentNodes();
      // Increase the 'colnum' of the column specification that are after the inserted column  
      for (Iterator iterator = contentNodes.iterator(); iterator.hasNext();) {
        AuthorNode node = (AuthorNode) iterator.next();
        if(isElement(node, ELEMENT_NAME_COLSPEC)) {
          AttrValue colSpecNumber= ((AuthorElement)node).getAttribute(ATTRIBUTE_NAME_COLNUM);
          if(colSpecNumber != null) {
            int colSpecNr = Integer.parseInt(colSpecNumber.getValue());
            if (colSpecNr >= newColumnIndex + 1) {
              // If the col spec num is <= inserted column, increase it
              authorAccess.getDocumentController().setAttribute(
                  ATTRIBUTE_NAME_COLNUM,
                  new AttrValue("" + (colSpecNr + 1)),
                  (AuthorElement) node);
            }
          }
        }
      }

      // Look for the 'colSpec' which has a specific 'colSpecName'.
      for (Iterator iterator = contentNodes.iterator(); iterator.hasNext();) {
        AuthorNode node = (AuthorNode) iterator.next();
        if(isElement(node, ELEMENT_NAME_COLSPEC)) {
          AttrValue colSpecName = ((AuthorElement)node).getAttribute(ATTRIBUTE_NAME_COLNAME);
          if(colSpecName != null && relativeColSpecName.equals(colSpecName.getValue())) {
            // We found the 'colSpec', insert before or after it depending on the flag
            insertOffset = (insertBefore ? node.getStartOffset() : node.getEndOffset() + 1);
            break;
          }
        }        
      }
    } else {
      // There are no 'colspec's defined
      if(newColumnIndex == 0) {
        // Insert a column specification at the start of 'tgroup'
        insertOffset = tgroup.getStartOffset() + 1;
      }
    }    

    if (insertOffset != -1) {
      String newColSpecName = getUniqueColSpecName(colSpecs, newColumnIndex + 1);
      
      StringBuffer newColSpecFragment = new StringBuffer();
      newColSpecFragment.append("<" + ELEMENT_NAME_COLSPEC);
      if (namespace != null) {
        newColSpecFragment.append(" xmlns=\"" + namespace + "\"");
      }
      newColSpecFragment.append(
          " " + ATTRIBUTE_NAME_COLNAME + "=\"" + newColSpecName + "\"" +
          " " + ATTRIBUTE_NAME_COLNUM + "=\"" + (newColumnIndex + 1) + "\"" +
          "/>");

      // Insert the fragment with the new 'colspec'
      authorAccess.getDocumentController().insertXMLFragment(newColSpecFragment.toString(), insertOffset);
    } else {
      throw new AuthorOperationException(
      "Could not compute the index of the column to be inserted.");
    }
  }

  /**
   * Determine an unique column specification name for the column specification to be inserted.
   * 
   * @param colSpecs      The list with column specifications.
   * @param colSpecIndex  The index of the column specification, 1 based.
   */
  private String getUniqueColSpecName(Set colSpecs, int colSpecIndex) {
    String uniqueColSpecName = "newCol" + colSpecIndex;
    // The number of iteration for find a unique col spec name 
    boolean isUnique = false;
    while(!isUnique) {
      isUnique = true;
      for (Iterator iterator = colSpecs.iterator(); iterator.hasNext();) {
        CALSColSpec colSpec = (CALSColSpec) iterator.next();
        if(uniqueColSpecName.equals(colSpec.getColumnName())) {
          isUnique = false;
          uniqueColSpecName = "newCol" + colSpecIndex;
          colSpecIndex ++;
          break;
        }
      }
    }
    return uniqueColSpecName;
  }

  /**
   * @see ro.sync.ecss.extensions.commons.table.operations.InsertColumnOperationBase#getCellElementName(ro.sync.ecss.extensions.api.node.AuthorElement, int)
   */
  @Override
  protected String getCellElementName(AuthorElement row, int newColumnIndex) {
    return ELEMENT_NAME_ENTRY;
  }
}