/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.table.operations;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;

import ro.sync.ecss.extensions.commons.ui.OKCancelDialog;
import ro.sync.xml.XmlUtil;

/**
 * Dialog used to customize the insertion of a table (number of rows, columns, table caption).
 * It is used on standalone implementation.  
 */
public abstract class SATableCustomizerDialog extends OKCancelDialog implements TableCustomizerConstants {
  
  /**
   * If selected the user can specify the table title. 
   */
  private JCheckBox titleCheckbox;
  
  /**
   * Text field for specify the table title.
   */
  private JTextField titleTextField;
  
  /**
   * Used to specify the number of rows.
   */
  private JSpinner rowsSpinner;
  
  /**
   * Used to specify the number of columns.
   */
  private JSpinner columnsSpinner;
  
  /**
   * If selected an empty table header will be generated.
   */
  private JCheckBox headerCheckbox;
  
  /**
   * If selected an empty table footer will be generated.
   */
  private JCheckBox footerCheckbox;
  
  /**
   * Combo used to chose the table frame type.
   */
  private JComboBox frameCombo;
  
  /**
   * <code>true</code> if the table that is customized by this dialog has a footer.
   */
  private final boolean hasFooter;
  
  /**
   * <code>true</code> if the table customized by this dialog has a frame attribute.
   */
  private final boolean hasFrameAttribute;
  
  /**
   * If <code>true</code> the table model chooser will be shown.
   * The table model can be CALS or HTML.
   */
  private final boolean showModelChooser;
  
  /**
   * Radio button used to choose CALS table model.
   */
  private JRadioButton calsModelRadio;

  /**
   * <code>true</code> if the table type is simple.
   */
  private final boolean simpleTableModel;

  /**
   * Constructor.
   * 
   * @param parentFrame The parent {@link JFrame} of the dialog.
   * @param hasFooter If this table has a footer.
   * @param hasFrameAttribute If <code>true</code> the table has a frame attribute.
   * @param showModelChooser If <code>true</code> then show the dialog panel for choosing the table 
   * model, one of CALS or HTML.  
   */
  public SATableCustomizerDialog(
      JFrame parentFrame, boolean hasFooter, boolean hasFrameAttribute,
      boolean showModelChooser) {
    this(parentFrame, hasFooter, hasFrameAttribute, showModelChooser, false);
  }
  
  /**
   * Constructor.
   * 
   * @param parentFrame The parent {@link JFrame} of the dialog.  
   * @param hasFooter If this table has a footer.
   * @param hasFrameAttribute If <code>true</code> the table has a frame attribute.
   * @param showModelChooser If <code>true</code> then show the dialog panel for choosing the table 
   * model, one of CALS or HTML.
   * @param simpleTableModel If <code>true</code> then use the
   * simple table model instead of the HTML model.
   */
  public SATableCustomizerDialog(
      JFrame parentFrame, boolean hasFooter, boolean hasFrameAttribute,
      boolean showModelChooser, boolean simpleTableModel) {
    super(parentFrame, "Insert Table", true);
    this.hasFooter = hasFooter;
    this.hasFrameAttribute = hasFrameAttribute;
    this.showModelChooser = showModelChooser;
    this.simpleTableModel = simpleTableModel;
    
    JPanel mainPanel = new JPanel(new GridBagLayout());
    mainPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
    GridBagConstraints gridBagConstr = new GridBagConstraints();
    gridBagConstr.gridx = 0;
    gridBagConstr.gridy = 0;
    gridBagConstr.fill = GridBagConstraints.BOTH;
    gridBagConstr.weightx = 1;
    gridBagConstr.anchor = GridBagConstraints.WEST;
    gridBagConstr.gridwidth = 2;

		// Model chooser panel.
    JPanel modelPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 3, 3));
    modelPanel.setBorder(BorderFactory.createTitledBorder("Model"));
    
    ButtonGroup buttonGroup = new ButtonGroup();
    // Radio button for choosing CALS table model
    calsModelRadio = new JRadioButton("CALS");
    calsModelRadio.setName("CALS model");
    calsModelRadio.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        addValuesToFrameCombo(getFrameValues(TableInfo.TABLE_MODEL_CALS));
        updateTitleState(true);
      }
    });
    modelPanel.add(calsModelRadio);
    buttonGroup.add(calsModelRadio);

    if (simpleTableModel) {
      // Radio button for choosing the simple table model
      JRadioButton simpleTableModelRadio = new JRadioButton("Simple");
      simpleTableModelRadio.setName("Simple table model");
      simpleTableModelRadio.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          addValuesToFrameCombo(getFrameValues(TableInfo.TABLE_MODEL_DITA_SIMPLE));
          updateTitleState(false);
        }
      });
      modelPanel.add(simpleTableModelRadio);
      buttonGroup.add(simpleTableModelRadio);
    } else {
      // Radio button for choosing HTML table model
      JRadioButton htmlModelRadio = new JRadioButton("HTML");
      htmlModelRadio.setName("HTML model");
      htmlModelRadio.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
          addValuesToFrameCombo(getFrameValues(TableInfo.TABLE_MODEL_HTML));
        }
      });
      modelPanel.add(htmlModelRadio);
      buttonGroup.add(htmlModelRadio);
    }
    
    int tableModel = TableInfo.TABLE_MODEL_CUSTOM;
    if (showModelChooser) {
      // Model chooser panel must be visible
      mainPanel.add(modelPanel, gridBagConstr);      
      tableModel = TableInfo.TABLE_MODEL_CALS;
      calsModelRadio.setSelected(true);
    }
    
    // Title check box
    titleCheckbox = createTitleCheckbox();    
    titleCheckbox.addActionListener(new ActionListener() {
      public void actionPerformed(ActionEvent e) {
        titleTextField.setEditable(titleCheckbox.isSelected());
      }
    });
    
    titleCheckbox.setBorder(BorderFactory.createEmptyBorder());
    gridBagConstr.gridy ++;
    gridBagConstr.gridx = 0;
    gridBagConstr.weightx = 0;
    gridBagConstr.gridwidth = 1;
    gridBagConstr.insets = new Insets(5, 0, 5, 5);
    gridBagConstr.fill = GridBagConstraints.NONE;
    mainPanel.add(titleCheckbox, gridBagConstr);
    
    // Title text field
    titleTextField = new JTextField();
    titleTextField.setName("Title text field");
    gridBagConstr.gridx ++;
    gridBagConstr.weightx = 1;
    gridBagConstr.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstr.insets = new Insets(5, 0, 5, 0);
    mainPanel.add(titleTextField, gridBagConstr);

    JPanel sizePanel = new JPanel(new GridBagLayout());
    sizePanel.setBorder(BorderFactory.createTitledBorder("Table Size"));
    
    gridBagConstr.gridy ++;
    gridBagConstr.gridx = 0;
    gridBagConstr.weightx = 1;
    gridBagConstr.fill = GridBagConstraints.HORIZONTAL;
    gridBagConstr.gridwidth = 2;
    gridBagConstr.insets = new Insets(5, 0, 5, 0);
    mainPanel.add(sizePanel, gridBagConstr);
       
    // 'Rows' label
    JLabel rowsLabel = new JLabel("Rows");
    GridBagConstraints c = new GridBagConstraints();
    c.gridx = 0;
    c.gridy = 0;
    c.anchor = GridBagConstraints.WEST;
    c.fill = GridBagConstraints.HORIZONTAL;
    c.weightx = 0;
    c.insets = new Insets(0, 5, 5, 5);
    sizePanel.add(rowsLabel, c);
    
    // Number of rows text field
    rowsSpinner = new JSpinner();
    rowsSpinner.setName("Rows spinner");
    rowsSpinner.setModel(new SpinnerNumberModel(2, 0, 100, 1));
    c.gridx++;
    c.weightx = 1;
    sizePanel.add(rowsSpinner, c);
    
    // 'Columns' label
    JLabel columnsLabel = new JLabel("Columns");
    c.gridx++;
    c.weightx = 0;
    sizePanel.add(columnsLabel, c);
    
    // Number of rows text field
    columnsSpinner = new JSpinner();
    columnsSpinner.setName("Columns spinner");
    columnsSpinner.setModel(new SpinnerNumberModel(2, 0, 100, 1));
    c.gridx++;
    c.weightx = 1;
    sizePanel.add(columnsSpinner, c);

    JPanel headerFooterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    gridBagConstr.gridx = 0;
    gridBagConstr.gridy ++;
    gridBagConstr.gridwidth = 2;
    gridBagConstr.insets = new Insets(5, 0, 5, 0);
    mainPanel.add(headerFooterPanel, gridBagConstr);
    
    // 'Header' check box
    headerCheckbox = new JCheckBox("Generate table header");
    headerCheckbox.setName("Header checkbox");
    headerCheckbox.setBorder(BorderFactory.createEmptyBorder());
    headerFooterPanel.add(headerCheckbox);

    if (hasFooter) {
      headerFooterPanel.add(new JLabel("  "));
      // 'Footer' check box
      footerCheckbox = new JCheckBox("Generate table footer");
      footerCheckbox.setName("Footer checkbox");
      footerCheckbox.setBorder(BorderFactory.createEmptyBorder());
      headerFooterPanel.add(footerCheckbox);
    }
    
    if (hasFrameAttribute) {
      // 'Frame' label
      JLabel frameLabel = new JLabel("Frame");
      gridBagConstr.gridx = 0;
      gridBagConstr.gridy ++;
      gridBagConstr.gridwidth = 1;
      gridBagConstr.weightx = 0;
      gridBagConstr.fill = GridBagConstraints.NONE;
      mainPanel.add(frameLabel, gridBagConstr);

      // Frame combo box
      frameCombo = new JComboBox();
      frameCombo.setName("Frame combo");
      addValuesToFrameCombo(getFrameValues(tableModel));

      gridBagConstr.gridx ++;
      gridBagConstr.weightx = 1;
      gridBagConstr.fill = GridBagConstraints.HORIZONTAL;
      mainPanel.add(frameCombo, gridBagConstr);
    }

    //Add the main panel
    getContentPane().add(mainPanel, BorderLayout.CENTER);
    
    pack();
    setResizable(false);
  }
  
  /**
   * Update the enabled state of the title section.
   * 
   * @param enabled <code>true</code> if the title is enabled.
   */
  private void updateTitleState(boolean enabled) {
    titleCheckbox.setEnabled(enabled);
    titleTextField.setEditable(enabled && titleCheckbox.isSelected());
  }

  /**
   * Compute the possible values for the <code>frame</code> attribute.
   * 
   * @param tableModel The table model. 
   * One of the constants: 
   * {@link TableInfo#TABLE_MODEL_CALS}, {@link TableInfo#TABLE_MODEL_CUSTOM},
   * {@link TableInfo#TABLE_MODEL_DITA_SIMPLE}, {@link TableInfo#TABLE_MODEL_HTML}.
   * @return Returns the possible values for the <code>frame</code> attribute. 
   */
  protected abstract String[] getFrameValues(int tableModel);

  /**
   * Creates the title checkbox with an implementation specific name.
   * 
   * @return The title checkbox customized according to implementation.
   */
  protected abstract JCheckBox createTitleCheckbox();

  /**
   * Add the possible values to the frame combo.
   */
  private void addValuesToFrameCombo(String[] frameValues) {
    frameCombo.removeAllItems();
    for (int i = 0; i < frameValues.length; i++) {
      frameCombo.addItem(frameValues[i]);
    }
  }

  /**
   * Show the dialog to customize the table attributes.
   * 
   * @return The {@link TableInfo} object with informations about the table 
   * to be inserted. 
   * If <code>null</code> then the user canceled the table insertion.
   */
  public TableInfo showDialog() {
    // Reset components to default values
    titleTextField.setEditable(true);
    titleTextField.setText("");
    titleCheckbox.setSelected(true);

    // Set the default number of rows and columns
    rowsSpinner.setValue(new Integer(3));
    columnsSpinner.setValue(new Integer(2));

    // Header and footer
    headerCheckbox.setSelected(true);
    if (hasFooter) {
      footerCheckbox.setSelected(false);
    }
    
    // Request focus in title field
    titleTextField.requestFocus();
    
    super.setVisible(true);
    
    TableInfo tableInfo = null;
    if(getResult() == RESULT_OK) {
      String title = null;
      if(titleCheckbox.isSelected()) {
        title = titleTextField.getText();
        // EXM-11910 Escape the table title.
        title = XmlUtil.escape(title);
      }
      int rowsNumber = ((Integer)rowsSpinner.getValue()).intValue();
      int columnsNumber = ((Integer)columnsSpinner.getValue()).intValue();
      // Compute the value of the table model
      int tableModel = TableInfo.TABLE_MODEL_CUSTOM;
      if(showModelChooser) {
        if (calsModelRadio.isSelected()) {
          tableModel = TableInfo.TABLE_MODEL_CALS;
        } else {
          if (simpleTableModel) {
            tableModel = TableInfo.TABLE_MODEL_DITA_SIMPLE;
          } else {
            tableModel = TableInfo.TABLE_MODEL_HTML;
          }
        }
      }
      tableInfo = 
        new TableInfo(
            title, 
            rowsNumber, 
            columnsNumber, 
            headerCheckbox.isSelected(), 
            hasFooter? footerCheckbox.isSelected() : false, 
            hasFrameAttribute ? (String) frameCombo.getSelectedItem() : null,
            tableModel);
    } else {
      // Cancel was pressed
    }
    return tableInfo;
  }
}