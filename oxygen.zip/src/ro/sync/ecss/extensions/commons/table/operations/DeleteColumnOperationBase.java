/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.commons.table.operations;

import java.util.ArrayList;

import javax.swing.text.BadLocationException;

import ro.sync.ecss.extensions.api.ArgumentDescriptor;
import ro.sync.ecss.extensions.api.ArgumentsMap;
import ro.sync.ecss.extensions.api.AuthorAccess;
import ro.sync.ecss.extensions.api.AuthorOperationException;
import ro.sync.ecss.extensions.api.AuthorTableCellSpanProvider;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Base implementation for operations used to delete a table column.
 */
public abstract class DeleteColumnOperationBase extends AbstractTableOperation {
  
  /**
   * The table element.
   */
  protected AuthorElement tableElem = null;
  
  /**
   * The index of the deleted column. 
   */
  protected int deletedColumnIndex = -1;

  /**
   * Constructor.
   * 
   * @param documentTypeHelper The table helper specific to a document type. 
   * An implementation of {@link ro.sync.ecss.extensions.commons.table.operations.AuthorTableHelper}.
   */
  public DeleteColumnOperationBase(AuthorTableHelper documentTypeHelper) {
    super(documentTypeHelper);
  }

  /**
   * Delete the table column at the caret position. 
   * For this operation the caret must be inside a table cell.
   * 
   * @see ro.sync.ecss.extensions.api.AuthorOperation#doOperation(ro.sync.ecss.extensions.api.AuthorAccess, ro.sync.ecss.extensions.api.ArgumentsMap)
   */
  public void doOperation(AuthorAccess authorAccess, ArgumentsMap args)
      throws IllegalArgumentException, AuthorOperationException {
    // Reset temporary fields.
    tableElem = null;
    int deletedRowIndex = -1;
    deletedColumnIndex = -1;
    
    // Test if the operation is available for the node at the caret position 
    try {
      AuthorNode nodeAtCaret = 
        authorAccess.getDocumentController().getNodeAtOffset(authorAccess.getEditorAccess().getCaretOffset());
      AuthorElement currentCellElem = 
        getElementAncestor(nodeAtCaret, AuthorTableHelper.TYPE_CELL);
      AuthorElement currentRowElem = 
        getElementAncestor(nodeAtCaret, AuthorTableHelper.TYPE_ROW);
      tableElem = 
        getElementAncestor(nodeAtCaret, AuthorTableHelper.TYPE_TABLE);
      if (currentCellElem != null && tableElem != null) {
        // Determine the index of column to be deleted
        int[] cellIndices = authorAccess.getTableAccess().getTableCellIndex(currentCellElem);
        deletedRowIndex = cellIndices[0];
        deletedColumnIndex = cellIndices[1];
        
        ArrayList intervals = new ArrayList();
        // For all the table rows delete the cell at the column index
        int rowsNumber = authorAccess.getTableAccess().getTableRowCount(tableElem);
        int colsNumber = authorAccess.getTableAccess().getTableNumberOfColumns(tableElem);
        AuthorTableCellSpanProvider spanProvider = 
          tableHelper.getTableCellSpanProvider(tableElem);
        for (int i = 0; i < rowsNumber; i++) {
          AuthorElement cell = authorAccess.getTableAccess().getTableCellAt(i, deletedColumnIndex, tableElem);
          if (cell != null) {
            int[] spanIndices = authorAccess.getTableAccess().getTableColSpanIndices(cell);
            Integer colSpanInteger = spanProvider.getColSpan(cell);
            Integer rowSpanInteger = spanProvider.getRowSpan(cell);
            int colSpan = colSpanInteger != null ? colSpanInteger.intValue() : 1;
            int rowSpan = rowSpanInteger != null ? rowSpanInteger.intValue() : 1;
            if (colSpan == 1) {
              // Delete the cell only if the column span is 1 (one).
              intervals.add(new int[] {cell.getStartOffset(), cell.getEndOffset()});
            } else {
              // Decrease the column span of the cell with one
              updateTableColSpan(authorAccess, spanProvider, cell, spanIndices[0] + 1, spanIndices[1] + 1);
            }
            if (rowSpan > 1) {
              // Skip the next cells above, since they are actually parts of the same cell.
              i += (rowSpan - 1);
            }
          } else {
            // The current row does not have a cell at column index.
          }
        }
        
        if (!intervals.isEmpty()) {
          // Create the arrays with the intervals.
          int[] startOffsets = new int[intervals.size()];
          int[] endOffsets = new int[intervals.size()];
          for (int i = 0; i < startOffsets.length; i++) {
            int[] interval = (int[]) intervals.get(i);
            startOffsets[i] = interval[0];
            endOffsets[i] = interval[1];
          }
          // Delete the given intervals.
          authorAccess.getDocumentController().multipleDelete(tableElem, startOffsets, endOffsets);
        }
        
        tableHelper.updateTableColumnNumber(
            authorAccess, 
            tableElem, 
            colsNumber - 1);
        
        // EXM-10373 Try to set the caret position in the row to a position adjacent to the deleted cell
        AuthorElement caretCell = authorAccess.getTableAccess().getTableCellAt(deletedRowIndex, deletedColumnIndex, tableElem);
        if (caretCell != null) {
          authorAccess.getEditorAccess().setCaretPosition(caretCell.getStartOffset());
        } else {
          authorAccess.getEditorAccess().setCaretPosition(currentRowElem.getEndOffset());
        }
      } else {
        // This operation is available only if the caret is positioned inside a table cell 
      }
    } catch (BadLocationException e) {
      throw new AuthorOperationException(
          "The operation cannot be performed due to: " + e.getMessage(), e);
    }
  }

  /**
   * Update the column span for the table cell that is included into the deleted
   * column.
   * 
   * @param authorAccess  The author access.
   * Provides access to specific informations and actions for 
   * editor, document, workspace, tables, change tracking, utility a.s.o.
   * @param spanProvider  The table span provider.
   * The object responsible for providing information 
   * about the cell spanning.
   * @param cell          The table cell.
   * @param colStartIndex The new column start index, 1 based.
   * @param colEndIndex   The new column end index, 1 based.
   * 
   * @throws AuthorOperationException When the operation fails.
   */
  protected abstract void updateTableColSpan(
      AuthorAccess authorAccess,
      AuthorTableCellSpanProvider spanProvider, 
      AuthorElement cell, 
      int colStartIndex, 
      int colEndIndex) throws AuthorOperationException;

  /**
   * No arguments for this operation.
   *  
   * @see ro.sync.ecss.extensions.api.AuthorOperation#getArguments()
   */
  public ArgumentDescriptor[] getArguments() {
    return null;
  }

  /**
   * @see ro.sync.ecss.extensions.api.Extension#getDescription()
   */
  public String getDescription() {
    return "Delete the current table column.";
  }
}