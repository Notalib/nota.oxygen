/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

/**
 * Interface defining an author extension operation. 
 * The operations are executed by the Author actions.
 */
public interface AuthorOperation extends Extension {
  
  /**
   * Represents the namespace argument.
   * The value is <code>'namespace'</code>.
   */
  public static final String NAMESPACE_ARGUMENT = "namespace";
  
  /**
   * The <code>namespace</code> argument descriptor.
   */
  public static final ArgumentDescriptor NAMESPACE_ARGUMENT_DESCRIPTOR =
    new ArgumentDescriptor(NAMESPACE_ARGUMENT, 
        ArgumentDescriptor.TYPE_STRING, 
        "The context namespace");
  
  /**
   * Perform the actual operation. This method is typically called from an
   * {@link javax.swing.Action#actionPerformed(java.awt.event.ActionEvent)}
   * if used from Oxygen stand-alone distribution or 
   * {@link org.eclipse.jface.action.Action#run()} if used from the Oxygen
   * Eclipse plugin.
   * 
   * @param authorAccess The author access.
   * Provides access to specific informations and actions for 
   * editor, document, workspace, tables, change tracking, utility a.s.o.
   * @param args The map of arguments. <strong>All the arguments defined by method 
   * {@link #getArguments()} must be present in the map of arguments.</strong>
   * @throws IllegalArgumentException Thrown when one or more arguments are illegal.
   * @throws AuthorOperationException Thrown when the operation fails.
   */
  void doOperation(AuthorAccess authorAccess, ArgumentsMap args) 
    throws IllegalArgumentException, AuthorOperationException;
  
  /**
   * @return An array of {@link ArgumentDescriptor} representing 
   * the arguments this operation uses.
   */
  ArgumentDescriptor[] getArguments();
}