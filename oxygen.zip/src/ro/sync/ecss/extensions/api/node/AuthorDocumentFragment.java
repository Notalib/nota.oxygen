/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.node;

import java.util.List;

import javax.swing.text.BadLocationException;

import ro.sync.ecss.changetracking.ChangeMarker;
import ro.sync.ecss.extensions.api.Content;

/**
 * Represents a fragment of an XML document.
 * <br/>
 * <br/>
 * For the following XML code fragment:
 * <br/>
 * <code>&lt;chapter&gt;content text content&lt;sect1&gt;text content&lt;sect11&gt;text content&lt;/sect11&gt;text&lt;/sect1&gt;text&lt;sect2&gt;text content&lt;/sect2&gt;text content text content&lt;/chapter&gt;</code>
 * <br/>
 * the corresponding document fragment structure can be represented as:
 * <br/>
 * <br/>
 * <img src="AuthorDocumentFragmentArchitecture.gif"/>
 * <br/>
 * The rectangle represents the content of the fragment and the red markers represent special control characters which are used 
 * to point to the start and the end offsets of the fragment containing nodes.  
 *
 */
public class AuthorDocumentFragment {

  /**
   * Content holding the fragment characters.
   */
  private Content content;

  /**
   * Nodes that make up this fragment.
   */
  private List<AuthorNode> nodes;

  /**
   * Number of elements it splits to the right.
   */
  private int righSplits;

  /**
   * Number of elements it splits to the left.
   */
  private int leftSplits;
  
  /**
   * The change marks for this fragment, can be null.
   * 
   * If the fragment is created when change tracking is turned OFF and the 
   * selection contains Track Changes then the fragment will contain 
   * the list of changes which intersected its region, made relative to the 
   * fragment content.
   * 
   * If the fragment is created when change tracking in turned ON then the 
   * fragment will contain the selection with all changes accepted (so the 
   * list will be always NULL).
   */
  private List<ChangeMarker> changeMarks;
  
  /**
   * Constructor.
   *
   * @param content The {@link Content} holding the fragment's content.
   * @param elements Elements that make up this fragment.
   * @param leftSplits Number of elements it splits to the left.
   * @param righSplits Number of elements it splits to the right.
   */
  public AuthorDocumentFragment(Content content, List<AuthorNode> elements, int leftSplits, int righSplits) {
    this(content, elements, leftSplits, righSplits, null);
  }
  
  /**
   * Constructor.
   *
   * @param content The {@link Content} holding the fragment's content.
   * @param elements Elements that make up this fragment.
   * @param leftSplits Number of elements it splits to the left.
   * @param righSplits Number of elements it splits to the right.
   * @param changeMarkers The list of change markers
   */
  public AuthorDocumentFragment(Content content, List<AuthorNode> elements, int leftSplits, int righSplits, List<ChangeMarker> changeMarkers) {
    this.content = content;
    this.nodes = elements;
    this.leftSplits = leftSplits;
    this.righSplits = righSplits;
    changeMarks = changeMarkers;
  }

  /**
   * @return the {@link Content} object holding this fragment's content.
   */
  public Content getContent() {
    return content;
  }

  /**
   * @return The number of characters, including sentinels (element start and end markers), 
   * present in the fragment.
   */
  public int getLength() {
    return content.getLength();
  }

  /**
   * @return The nodes that make up this fragment.
   */
  public List<AuthorNode> getContentNodes() {
    return nodes;
  }
  
  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    String toString = "";
    try {
      toString = "Fragment content '" + content.getString(0, content.getLength()).replace((char)0, 'X') +
      "'\n Elements '" + nodes + "\nRight splits:" + righSplits + " Left splits:" + leftSplits;
    } catch (BadLocationException e) {
      // Ignored
    }
    return toString;
  }

  /**
   * @return Number of nodes the fragment splits to the left.
   */
  public int getLeftSplits() {
    return leftSplits;
  }

  /**
   * @return Number of nodes the fragment splits to the right.
   */
  public int getRightSplits() {
    return righSplits;
  }

  /**
   * Set the number of the elements the fragment splits to the left.
   * 
   * @param leftSplits The left splits count.
   */
  public void setLeftSplits(int leftSplits) {
    this.leftSplits = leftSplits;
  }
  
  /**
   * Set the number of the elements the fragment splits to the right.
   * 
   * @param righSplits The right splits count.
   */
  public void setRighSplits(int righSplits) {
    this.righSplits = righSplits;
  }
  
  /**
   * Returns the list with the change marks.
   * If the fragment is created when change tracking is turned OFF and the 
   * selection contains Track Changes then the fragment will contain 
   * the list of changes which intersected its region, made relative to 
   * the fragment content.
   * 
   * If the fragment is created when change tracking in turned ON then the 
   * fragment will contain the selection with all changes accepted (so the 
   * list will be always NULL).
   * 
   * @return Returns list with {@link ChangeMarker}.
   */
  public List<ChangeMarker> getChangeMarks() {
    return changeMarks;
  }

  /**
   * Set the list with the change markers.
   * 
   * @param markers The change markers list.
   */
  public void setChangeMarks(List<ChangeMarker> markers) {
    changeMarks = markers;
  }
  
  /**
   * @return <code>true</code> If the fragment is empty.
   */
  public boolean isEmpty() {
    return content.getLength() == 0;
  }
}