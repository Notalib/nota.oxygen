/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.node;

import java.net.URL;

import javax.swing.text.BadLocationException;

/**
 * Base interface for all Author nodes. 
 * The Author nodes model is similar with the DOM model with the difference 
 * that the TEXT nodes do not exists in this model. The text from the document
 * is kept separately into a data structure similar to Content from Swing. 
 * The nodes have start and end pointers into the Content, see <code>{@link #getStartOffset()}</code>
 * and <code>{@link #getEndOffset()}</code> methods. 
 */
public interface AuthorNode {
  /**
   * Element node type.
   * The value is 0.
   */
  int NODE_TYPE_ELEMENT = 0;  
  /**
   * Text node type.
   * The value is 1.
   */
  int NODE_TYPE_TEXT = 1;
  /**
   * Document node type.
   * The value is 2.
   */
  int NODE_TYPE_DOCUMENT = 2;
  /**
   * Comment node type.
   * The value is 3.
   */
  int NODE_TYPE_COMMENT = 3;
  /**
   * CDATA node type.
   * The value is 4.
   */
  int NODE_TYPE_CDATA = 4;
  /**
   * Processing instruction node type.
   * The value is 5.
   */
  int NODE_TYPE_PI = 5;  
  /**
   * Pseudo element node type.
   * The value is 6.
   */
  int NODE_TYPE_PSEUDO_ELEMENT = 6;  
  /**
   * Reference node type (entity or other reference nodes, e.g. <code>xinclude</code> elements).
   * The value is 7.
   */
  int NODE_TYPE_REFERENCE = 7;  
  /**
   * Pseudo DOCTYPE node type.
   * The value is 8.
   */
  int NODE_TYPE_PSEUDO_DOCTYPE = 8;
  /**
   * Name of CDATA node.
   * The value is <code>#cdata</code>.
   */
  String NODE_NAME_CDATA = "#cdata";
  /**
   * Name of COMMENT node.
   * The value is <code>#comment</code>.
   */
  String NODE_NAME_COMMENT = "#comment";
  /**
   * Name of DOCUMENT node.
   * The value is <code>#document</code>.
   */
  String NODE_NAME_DOCUMENT = "#document";
  /**
   * Name of PI node.
   * The value is <code>#processing-instruction</code>.
   */
  String NODE_NAME_PI = "processing-instruction";
  
  /**
   * Returns the document to which this element belongs.
   * 
   * @return The {@link AuthorDocument} to which this element belongs.
   * Returns <code>null</code> if this element is part of a document fragment.
   * For more details see {@link AuthorDocumentFragment}.
   */
  AuthorDocument getOwnerDocument();
  
  /**
   * See if this node is a descendant of the given node.
   * 
   * @param ancestor The {@link AuthorNode} tested to see if it is an ancestor of this node.
   * @return <code>true</code> if the given node is an ancestor of this node.
   */
  boolean isDescendentOf(AuthorNode ancestor);
  
  /**
   * Returns the node type.
   * Can be one of the constants:
   * {@link #NODE_TYPE_CDATA}, {@link #NODE_TYPE_COMMENT}, {@link #NODE_TYPE_DOCUMENT},
   * {@link #NODE_TYPE_ELEMENT}, {@link #NODE_TYPE_PI}, {@link #NODE_TYPE_PSEUDO_DOCTYPE},
   * {@link #NODE_TYPE_PSEUDO_ELEMENT}, {@link #NODE_TYPE_REFERENCE}, {@link #NODE_TYPE_TEXT}.
   * 
   * @return The node type.
   */
  int getType();
  
  /**
   * @return The offset into the content corresponding to the start of the node, 
   * 0 based and inclusive.   
   */
  int getStartOffset();
  
  /**
   * @return The offset into the content corresponding to the end of the node, 
   * 0 based and inclusive.
   */
  int getEndOffset();
  
  /**
   * Returns the node name. Depending on the node type the method returns:
   * 
   * <ul>
   *   <li>{@link #NODE_TYPE_ELEMENT} - the qualified name of the element</li>
   *   <li>{@link #NODE_TYPE_CDATA} - the constant {@link #NODE_NAME_CDATA}</li>
   *   <li>{@link #NODE_TYPE_COMMENT} - the constant {@link #NODE_NAME_COMMENT} </li>
   *   <li>{@link #NODE_TYPE_DOCUMENT} - the constant {@link #NODE_NAME_DOCUMENT} </li>
   *   <li>{@link #NODE_TYPE_REFERENCE} - the name of the entity</li>
   *   <li>{@link #NODE_TYPE_PI} - the constant {@link #NODE_NAME_PI} </li>
   * </ul> 
   *  
   * @return The name of the node. 
   */
  String getName();
  
  /**
   * @return The {@link AuthorNode} representing the parent of this element, 
   * or <code>null</code> if this is the root element.
   */
  AuthorNode getParent();
  
  /**
   * Returns the display name of the node used for visual representation.
   * 
   * @return The display name.
   */
  String getDisplayName();
  
  /**
   * The returned URL represents the value of base URL in the current nodes context.
   * It is resolved taking into account the values of all the <code>'xml:base'</code> 
   * attributes from the ancestors and the document URL if necessary. 
   * <p>
   * If no <code>'xml:base'</code> attribute is present, the document system ID
   * will be returned.
   * 
   * See specification: <a href="http://www.w3.org/TR/xmlbase/">http://www.w3.org/TR/xmlbase/</a>.
   * 
   * @return The XML base URL.
   */
  URL getXMLBaseURL();
  
  /**
   * Returns the nodes text content. The returned value is obtained by adding all the descendants 
   * text content.
   * 
   * @return The node text content.
   * @throws BadLocationException If the text content cannot be obtained.
   */
  String getTextContent() throws BadLocationException;
}