/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.access;

import java.io.File;
import java.io.IOException;
import java.net.URL;

/**
 * Provides access to workspace specific information and actions. 
 */
public interface AuthorWorkspaceAccess {
  /**
   * @return The parent frame ({@link javax.swing.JFrame}) of the Oxygen application or the parent shell 
   * ({@link org.eclipse.swt.widgets.Shell}) if this is the Eclipse implementation.
   */
  Object getParentFrame();
  
  /**
   * Displays a file chooser for selecting a {@link File}.
   * 
   * @param title The file chooser title.
   * @param allowedExtensions Allowed file extensions.
   * @param filterDescr Description for the file filter.
   * @param openForSave <code>true</code> when the file chooser is used for saving, 
   * <code>false</code> if it is used for opening an existing file. 
   * @return The chosen file or <code>null</code> if the user canceled the dialog.
   */
  File chooseFile(String title, String[] allowedExtensions, String filterDescr, boolean openForSave);
  
  /**
   * Displays a file chooser for selecting a {@link File}.
   * 
   * @param title The file chooser title.
   * @param allowedExtensions Allowed file extensions.
   * @param filterDescr Description for the file filter.
   * @return The chosen file or <code>null</code> if the user canceled the dialog.
   */
  File chooseFile(String title, String[] allowedExtensions, String filterDescr);
  
  /**
   * Displays an URL chooser for selecting an {@link URL}.
   * 
   * @param title The chooser dialog title.
   * @param allowedExtensions Allowed extensions.
   * @param filterDescr Description for the filter.
   * @return The chosen URL or <code>null</code> if the user canceled the dialog.
   */
  URL chooseURL(String title, String[] allowedExtensions, String filterDescr);
  
  /**
   * @return <code>true</code> if this is the stand-alone Oxygen version or
   * <code>false</code> if it is the Oxygen Eclipse plug-in version.
   */
  boolean isStandalone();
  
  /**
   * Shows a question message dialog.
   * 
   * @param title The dialog title.
   * @param message The message to be presented to the user.
   * @param buttonNames The names of the buttons representing the choices in the dialog.
   * @param buttonIds The id for each button. Used to identify which button was pressed.
   * All Ids must be greater or equal to 0.
   * 
   * @return the id of the pressed button or -1 if the dialog was closed by other means.
   */
  int showConfirmDialog(String title, String message, String[] buttonNames, int[] buttonIds);
  
  /**
   * Presents an error message dialog.
   * 
   * @param message The error message.
   */
  void showErrorMessage(String message);
  
  /**
   * Presents an information message dialog.
   * 
   * @param message The information message.
   */
  void showInformationMessage(String message);
  
  /**
   * Opens the file at the specified {@link URL} in a new editor.
   * 
   * @param url The URL of the file to be opened.
   * @return <code>true</code> if the operation has succeeded.
   */
  boolean open(URL url);
  
  /**
   * Opens the specified {@link File} in a new editor.
   * 
   * @param file The file to be opened.
   * @return <code>true</code> if the operation has succeeded.
   */
  boolean open(File file);

  /**
   * Saves the content of all opened and unsaved Author editors.
   */
  void saveAll();
  
  /**
   * Delete the resource identified by the specified {@link URL}.
   * Currently supported protocols are:
   * <ul>
   * <li>file://</li>
   * <li>zip://</li>
   * <li>ftp://</li>
   * <li>sftp://</li>
   * <li>http://</li>
   * <li>https://</li>
   * </ul>
   * 
   * @param url The URL from where to delete a resource.
   * @throws IOException
   */
  void delete(URL url) throws IOException;
}