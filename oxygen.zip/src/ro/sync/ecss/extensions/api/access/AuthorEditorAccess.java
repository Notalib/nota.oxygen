/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.access;

import java.io.Reader;
import java.net.URL;

import ro.sync.ecss.extensions.api.AuthorCaretListener;
import ro.sync.ecss.extensions.api.AuthorMouseListener;
import ro.sync.ecss.extensions.api.AuthorViewToModelInfo;
import ro.sync.ecss.extensions.api.highlights.AuthorHighlighter;
import ro.sync.ecss.extensions.api.node.AuthorNode;
import ro.sync.exml.view.graphics.Point;
import ro.sync.exml.view.graphics.Rectangle;

/**
 * Provides access to methods related to the Author editor actions and information.
 */
public interface AuthorEditorAccess {
  /**
   * Get selection start offset. It is inclusive.
   * 
   * @return The selection start offset, 0 based.
   */
  int getSelectionStart();
  
  /**
   * Get selection end offset. It is exclusive.
   * 
   * @return The selection end offset, 0 based.
   */
  int getSelectionEnd();
  
  /**
   * Get the selected text. The text does not contain XML tags. 
   * 
   * @return The selected text or an empty string if no selection is present.
   */
  String getSelectedText();
  
  /**
   * The current caret offset.
   * 
   * @return The caret offset, 0 based.
   */
  int getCaretOffset();
  
  /**
   * Delete the selected text, if any.
   */
  void deleteSelection();
  
  /**
   * @return <code>true</code> if there is a selection, <code>false</code> otherwise.
   */
  boolean hasSelection();
  
  /**
   * Select the word at caret, if any.
   */
  void selectWord();
  
  /**
   * Move the caret to the specified offset.
   * 
   * @param offset The offset where the caret should be positioned, 0 based.
   */
  void setCaretPosition(int offset);
  
  /**
   * Select the interval between start and end offset.
   *  
   * @param startOffset Inclusive start offset 
   * @param endOffset  Exclusive end offset
   */
  void select(int startOffset, int endOffset);

  /**
   * Compute the offsets of the word that contains the caret position.
   * 
   * @return An array with the start and end offsets of the word at caret or
   * <code>null</code> if the values couldn't be obtained.
   * The start offset is inclusive and greater or equal than 1.
   * The end offset is also inclusive and less or equal than the content length.
   */
  int[] getWordAtCaret();
  
  /**
   * Get the {@link URL} representing the editor location.
   * 
   * @return The editor location. It cannot be <code>null</code>.
   */
  URL getEditorLocation();
  
  /**
   * Get the position in the document corresponding to the point in the author viewport component.
   * 
   * @param x The "x" coordinate relative to the viewport origin.
   * @param y The "y" coordinate relative to the viewport origin.
   * @return  The {@link AuthorViewToModelInfo} containing the offset and the node
   * at offset corresponding to the given point. The method does not return <code>null</code>, 
   * instead an undefined view to model info object is returned if a valid one could not be determined.
   */
  AuthorViewToModelInfo viewToModel(int x, int y);
  
  /**
   * Adds a mouse listener to the current author page.
   * 
   * @param mouseListener The {@link AuthorMouseListener} to be added.
   */
  void addAuthorMouseListener(AuthorMouseListener mouseListener);
  
  /**
   * Removes the specified mouse listener from the current author page.
   * 
   * @param mouseListener The {@link AuthorMouseListener} to be removed. 
   */
  void removeAuthorMouseListener(AuthorMouseListener mouseListener);
  
  /**
   * Adds a caret listener to the Author page.
   * 
   * @param caretListener The {@link AuthorCaretListener} to be added.
   */
  void addAuthorCaretListener(AuthorCaretListener caretListener);
 
  /**
   * Removes the specified caret listener from the Author page.
   * 
   * @param caretListener The {@link AuthorCaretListener} to be removed.
   */
  void removeAuthorCaretListener(AuthorCaretListener caretListener);
  
  /**
   * Saves the author document content.
   */
  void save();
  
  /**
   * This method can be used to determine if the document from the editor contains unsaved modifications.
   * 
   * @return <code>true</code> if the document in the current editor contains unsaved modifications. 
   */
  boolean isModified();
  
  /**
   * This method can be used to determine if the document from the editor was ever saved.
   * 
   * @return <code>true</code> if the document in the current editor is new. 
   */
  boolean isNewDocument();
  
  /**
   * Refresh the rendering layout and CSS styles for this node and all its contents.
   * 
   * @param authorNode The node for which the layout and styles will be recomputed.
   */
  void refresh(AuthorNode authorNode);
  
  /**
   * Reload the CSS files and perform a refresh on the whole document to recompute
   * the layout and the styles for all the nodes based on the new CSS files
   * content.
   */
  void refresh();
  
  /**
   * Create a reader over the whole editor's content (exactly the XML content which gets saved on disk).
   * The unsaved changes are included. If change tracking highlights are present, they are also included as processing instructions.
   * @see ro.sync.ecss.changetracking.ChangeConstants for the processing instruction names
   * 
   * @return The content reader.In normal circumstances the reader should not be <code>null</code>.
   */
  Reader createContentReader();
  
  /**
   * Update the whole content of the editor with the one taken from the reader.
   * This will lose undo history and any modifications the editor may have.
   * 
   * @param reader The reader provided by the extension.
   */
  void reloadContent(Reader reader);
  
  /**
   * Take relative mouse coordinates and translate then to absolute on-screen coordinates.
   * 
   * @param x The "x" coordinate relative to the viewport origin.
   * @param y The "y" coordinate relative to the viewport origin.
   * @return  An array with the "x" and "y" coordinates relative to the screen.
   * 
   * @deprecated Use the getLocationOnScreenAsPoint(int x, int y) method instead. 
   */
  @Deprecated
  int[] getLocationOnScreen(int x, int y);
  
  /**
   * Take relative mouse coordinates and translate then to absolute on-screen coordinates.
   * 
   * @param x The "x" coordinate relative to the viewport origin.
   * @param y The "y" coordinate relative to the viewport origin.
   * @return  A point with the "x" and "y" coordinates relative to the screen. 
   *          It does not return a <code>null</code> Point.
   */
  Point getLocationOnScreenAsPoint(int x, int y);
  
  /**
   * Returns a representation of the caret shape for the specified document offset.
   * 
   * @param offset The document offset to get the corresponding caret shape for. 
   * @return An array of int values corresponding to the caret shape: 
   * the caret "x" coordinate relative to the viewport origin, 
   * the caret "y" coordinate relative to the viewport origin, 
   * the caret rectangle width and 
   * the caret rectangle height.
   *  
   *  @deprecated use modelToViewRectangle(int offset) instead
   */
  @Deprecated
  int[] modelToView(int offset);
  
  /**
   * Returns a representation of the caret shape for the specified document offset.
   * 
   * @param offset The document offset to get the corresponding caret shape for. 
   * @return The caret rectangle shape. It does not return a <code>null</code> Rectangle.
   *  
   */
  Rectangle modelToViewRectangle(int offset);
  
  /**
   * Get the highlighter which can be used to add/remove/manage the custom user highlights
   * @return The highlighter which can be used to add/remove/manage the custom user highlights.
   */
  AuthorHighlighter getHighlighter();
}