/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import java.net.URL;

import ro.sync.contentcompletion.xml.SchemaManagerFilter;
import ro.sync.ecss.extensions.api.link.ElementLocator;
import ro.sync.ecss.extensions.api.link.ElementLocatorProvider;

/**
 * Abstract class representing a bundle for all extensions handlers.
 * Extensions of this class must be defined for every document type association defined
 * in the <b>Preferences</b>/<b>Document type association</b> section.
 * <br>
 * The bundle is created each time the document type association where it is defined matches 
 * the current document opened in an editor or the properties of the enclosing 
 * document type have been modified while the document type is active.
 * At most one instance of an extensions bundle exist at a given time in the editor.
 * <br>
 * Note: <i>References to objects that need to be persistent throughout the
 * existence of an editor must not be kept here.</i>. 
 */
public abstract class ExtensionsBundle implements Extension {
  
  /**
   * Creates a new {@link AuthorReferenceResolver} instance used to expand 
   * content references.
   * The method is called each time an opened document in an Author editor page 
   * matches the document type association where the extensions bundle is defined.
   * 
   * @return A new {@link AuthorReferenceResolver} instance.
   */
  public AuthorReferenceResolver createAuthorReferenceResolver() {
    return null;
  }
  
  /**
   * Creates a new {@link StylesFilter} instance for the CSS styles filtering. 
   * Use this to replace the default styles associated to a node.
   * The method is called each time an opened document in an Author editor page 
   * matches the document type association where the extensions bundle is defined.
   * 
   * @return A new {@link StylesFilter} instance.
   */
  public StylesFilter createAuthorStylesFilter() {
    return null;
  }
  
  /**
   * Creates a new {@link AuthorTableCellSpanProvider} instance
   * responsible for providing information about the table cells spanning.
   * The table cell span provider is not reused between different tables.
   * The method is called for each table in the document so a new instance 
   * should be provided each time.
   * 
   * @return A new {@link AuthorTableCellSpanProvider} instance.
   */
  public AuthorTableCellSpanProvider createAuthorTableCellSpanProvider() {
    return null;
  }
  
  /**
   * Creates a new {@link AuthorTableColumnWidthProvider} instance
   * responsible for providing information and for handling modifications 
   * regarding table width and column widths.
   * The table column width provider is not reused between different tables.
   * The method is called for each table in the document so a new instance
   * should be provided each time.
   * 
   * @return A new {@link AuthorTableColumnWidthProvider} instance.
   */
  public AuthorTableColumnWidthProvider createAuthorTableColumnWidthProvider() {
    return null;
  }

  /**
   * Returns the {@link AuthorExtensionStateListener} which will be notified 
   * when the Author extension where it is defined is activated and deactivated 
   * during the detection process.
   * This method is called each time the Document Type association where the 
   * Author extension and the extensions bundle are defined matches a document 
   * opened in an Author page.
   * 
   * @return A new {@link AuthorExtensionStateListener} instance.
   */
  public AuthorExtensionStateListener createAuthorExtensionStateListener() {
    return null;
  }
  
  /**
   * Creates a new {@link ro.sync.exml.editor.xmleditor.pageauthor.AuthorDnDListener} instance
   * responsible for handling AWT author drag and drop events.
   * This method is called each time the Document Type association where 
   * the extensions bundle is defined matches a document opened in an Author page.
   *  
   * @return The AWT drag and drop listener implementation.
   */
  public ro.sync.exml.editor.xmleditor.pageauthor.AuthorDnDListener createAuthorAWTDndListener() {
    return null;
  }
  
  /**
   * Creates a new {@link com.oxygenxml.editor.editors.author.AuthorDnDListener} instance 
   * responsible for handling SWT author drag and drop events.
   * This method is called each time the Document Type association where 
   * the extensions bundle is defined matches a document opened in an Author page.
   *   
   * @return The SWT drag and drop listener implementation.
   */
  public com.oxygenxml.editor.editors.author.AuthorDnDListener createAuthorSWTDndListener() {
    return null;
  }
  
  /**
   * Creates a new {@link com.oxygenxml.editor.editors.TextDnDListener} instance 
   * responsible for handling SWT text drag and drop events.
   * This method is called each time the Document Type association where 
   * the extensions bundle is defined matches a document opened in a Text page.
   *  
   * @return The SWT drag and drop listener implementation.
   */
  public com.oxygenxml.editor.editors.TextDnDListener createTextSWTDndListener() {
    return null;
  }

  /**
   * Creates a new {@link ElementLocatorProvider} instance responsible
   * for providing an implementation of an {@link ElementLocator} 
   * based on the structure of a link. The {@link ElementLocator} is capable
   * of locating an element pointed by the supplied link.
   * This method is called each time an element needs to be located based on a
   * link specification.
   * 
   * @return A new {@link ElementLocatorProvider} instance.
   */
  public ElementLocatorProvider createElementLocatorProvider() {
    return null;
  }
  
  /**
   * Creates a new {@link SchemaManagerFilter} instance used to filter
   * the content completion proposals from the schema manager.
   * This method is called each time the document type where the extensions bundle 
   * is defined matches a document opened in an editor.
   * 
   * @return A new {@link SchemaManagerFilter} instance.
   */
  public SchemaManagerFilter createSchemaManagerFilter() {
    return null;
  }
  
  /**
   * Creates a new {@link AttributesValueEditor} instance used to get values for the current
   * attribute.
   * This is used especially from the "Attributes View" and from attributes editing dialogs 
   * available on Author mode and Outliner.
   * 
   * @param forEclipsePlugin  If <code>true</code> the code is called from the Eclipse plugin.
   * @return A new {@link AttributesValueEditor} instance.
   */
  public AttributesValueEditor createAttributesValueEditor(boolean forEclipsePlugin) {
    return null;
  }
  
  /**
   * @return the unique attributes identifier
   */
  public UniqueAttributesRecognizer getUniqueAttributesIdentifier() {
    return null;
  }
  
  /**
   * This should never return <code>null</code> if the {@link OptionsStorage}
   * support it is intended to be used.
   * If this returns <code>null</code> you will not be able to add 
   * {@link  ro.sync.ecss.extensions.api.OptionListener} or store and retrieve 
   * any options at all.
   * 
   * @return The unique identifier of the Document Type. 
   */
  public abstract String getDocumentTypeID();
  
  /**
   * When clicking a href the bundle can custom solve the href to an URL
   * @param linkHref The link href as derrived from the CSS
   * @return The resolved absolute URL if null if the default behavior will be performed
   */
  public URL resolveCustomHref(String linkHref) {
    return null;
  }
}