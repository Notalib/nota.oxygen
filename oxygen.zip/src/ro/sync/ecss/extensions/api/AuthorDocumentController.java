/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import javax.swing.text.BadLocationException;
import javax.swing.text.Segment;
import javax.swing.undo.UndoManager;

import ro.sync.ecss.extensions.api.node.AttrValue;
import ro.sync.ecss.extensions.api.node.AuthorDocument;
import ro.sync.ecss.extensions.api.node.AuthorDocumentFragment;
import ro.sync.ecss.extensions.api.node.AuthorElement;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Provides methods for modifying the Author document.
 */
public interface AuthorDocumentController extends AuthorStrictEditingSupport {

  /**
   * Deletes a document fragment between the start and end offset.
   * 
   * @param startOffset Start offset, 0 based, inclusive.
   * @param endOffset End offset, 0 based, inclusive.
   * @return <code>true</code> if the delete operation was successful.
   */
  boolean delete(int startOffset, int endOffset);
  
  /**
   * Delete a node.
   * 
   * @param node The {@link AuthorNode} to delete.
   * @return <code>true</code> if the delete node operation was successful. 
   */
  boolean deleteNode(AuthorNode node);
  
  /**
   * Replace the current root element with the new given one. 
   * The fragment must contain only one element, otherwise the replacement will not be performed.
   * 
   * @param fragment The document fragment containing the new root element.
   */
  void replaceRoot(AuthorDocumentFragment fragment);

  /**
   * Create a document fragment for the given range of offsets.
   * 
   * @param startOffset The start offset, 0 based, inclusive. 
   * @param endOffset The end offset, 0 based, inclusive.
   * @return A new {@link AuthorDocumentFragment}. 
   *         It does not return a <code>null</code> fragment.
   * @throws BadLocationException When the offsets are not between 0 and the 
   * content length, or the <code>startOffset</code> is greater than the <code>endOffset</code>.
   */
  AuthorDocumentFragment createDocumentFragment(int startOffset, int endOffset)
      throws BadLocationException;
  
  /**
   * Create a new {@link AuthorDocumentFragment} from an XML string in a specified context.
   * 
   * @param xmlFragment The XML Fragment.
   * @param contentOffset The offset where the XML fragment should be inserted.
   * @return The newly created {@link AuthorDocumentFragment}. 
   *         It does not return a <code>null</code> fragment.
   * @throws AuthorOperationException If the new fragment creation fails. 
   */
  AuthorDocumentFragment createNewDocumentFragmentInContext(String xmlFragment, int contentOffset)
      throws AuthorOperationException;  
  
  /**
   * Takes the given fragment and serializes it to XML text in the context 
   * of the current document.
   * 
   * The following code example extracts the selection as an XML fragment, 
   * processes and then reinserts it:
   * <p>
   * <hr><blockquote><pre>
   * if(authorAccess.getEditorAccess().hasSelection()) {
   *    AuthorDocumentController documentController = authorAccess.getDocumentController();
   *    AuthorDocumentFragment selectionAsAFragment = documentController.createDocumentFragment(
   *         authorAccess.getEditorAccess().getSelectionStart(), authorAccess.getEditorAccess().getSelectionEnd());
   *    String selectionAsXML = documentController.serializeFragmentToXML(selectionAsAFragment);
   *    
   *    //Deletes the selection
   *    authorAccess.getEditorAccess().deleteSelection();
   *    
   *    //Process the selectionAsXML fragment, modify it.
   *    //................
   *    
   *    //Insert the XML fragment back at caret position.
   *    documentController.insertXMLFragment(selectionAsXML, authorAccess.getEditorAccess().getCaretOffset());
   * }
   * </pre></blockquote><hr>
   * 
   * If the fragment contains change tracking highlights, they will be 
   * serialized as processing instructions.
   * 
   * @param fragment The {@link AuthorDocumentFragment} to serialize.
   * @return An equivalent {@link String} representation of the given fragment.
   *         It does not return a <code>null</code> String. If the fragment cannot be serialized
   *         it will return an empty String.
   * @throws BadLocationException If the serialization could not be accomplished, 
   * usually because the fragment was not properly built.
   */
  String serializeFragmentToXML(AuthorDocumentFragment fragment) throws BadLocationException;

  /**
   * Sets the value of an attribute in the specified element. 
   * Attributes set in this manner (as opposed to calling 
   * {@link AuthorElement#setAttribute(String, AttrValue)} directly) 
   * will be subject to undo/redo.
   * 
   * @param attributeName Name of the attribute being changed.
   * @param value New {@link AttrValue} for the attribute. If <code>null</code>, the attribute is 
   * removed from the element.
   * @param element The {@link AuthorElement} whose attribute is changing.
   */
  void setAttribute(String attributeName, AttrValue value, AuthorElement element);

  /**
   * Removes an attribute from the given element. 
   * Attributes removed in this manner (as opposed to calling 
   * {@link AuthorElement#setAttribute(String, AttrValue)} directly) will 
   * be subject to undo/redo.
   * 
   * @param attributeName Name of the attribute to remove.
   * @param element The {@link AuthorElement} whose attribute will be removed.
   */  
  void removeAttribute(String attributeName, AuthorElement element);

  /**
   * Returns the node at the given offset. The given offset must be
   * greater or equal to 0 and less than the current document length.
   * <br>
   * Note: 
   * <i>The left element marker is not considered to 
   * be inside an element but the right marker is.</i>
   * 
   * @param offset The offset in the content, zero based.
   * @return The {@link AuthorNode} containing the offset, 
   * or <code>null</code> when the actual document is <code>null</code>. 
   * @throws BadLocationException When the offset is negative or greater 
   * than the content length.
   */
  public AuthorNode getNodeAtOffset(int offset) throws BadLocationException;

  /**
   * Create a document fragment containing a copy of the node. 
   * The attributes of the elements will be copied. 
   * If <code>copyContent</code> is <code>true</code> the node content 
   * will be copied also.   
   * 
   * @param node The {@link AuthorNode} to be duplicated.
   * @param copyContent If <code>true</code> the content of the node will 
   * also be duplicated.
   * @return  The {@link AuthorDocumentFragment} containing the duplicated node.
   *          It does not return a <code>null</code> fragment.
   * @throws BadLocationException When the operation fails. 
   */
  AuthorDocumentFragment createDocumentFragment(AuthorNode node, boolean copyContent) throws BadLocationException;
  
  /**
   * Gets a sequence of text from the document text content.
   * The document text content can be obtained by adding all the text nodes
   * content.
   * <br/>
   * The <code>offset</code> is considered to be relative to the
   * text content start offset. So the 0 offset corresponds to the offset of 
   * the first valid char in the document.
   * <br/>
   * The <code>length</code> represents also a number of valid chars encountered
   * after the real start offset was determined.
   * <br/>
   * <br/>
   * For the document:
   * <code>
   * <br/>
   * [?PI?][article][!COMMENT][para]PARAGRAPH[/para][/article]
   * <br/>
   * </code>
   * <br/>
   * <code>getText(0, 18)</code> returns "PICOMMENTPARAGRAPH"
   * <br/>
   * <code>getText(5, 8)</code> returns "MENTPARA"
   *
   * @param offset The starting offset >= 0. 
   * @param length The number of characters to retrieve >= 0
   * @return The text
   * @deprecated  Use the API based on the {@link AuthorNode} to get only the displayed text
   *              without mark-up markers.
   * @exception BadLocationException The range given includes a position 
   *            that is not a valid position within the document text content.
   */
  @Deprecated
  String getText(int offset, int length) throws BadLocationException;
  
  /**
   * Returns the length of the text content of the document. This is the number of valid 
   * characters in the document text. The length
   * can be determined by the adding all text nodes content length.
   * <br/> 
   * <br/>
   * For the document:
   * <code>
   * <br/>
   * [?PI?][article][!COMMENT][para]PARAGRAPH[/para][/article]
   * <br/>
   * </code>
   * 
   * The text content length will be:
   * <br/>
   * <code>
   * "PI".length() + "COMMENT".length() + "PARAGRAPH".length()
   * <br/>
   * 2 + 7 + 9 = 18
   *
   * @deprecated  Use the API based on the {@link AuthorNode} to get the length 
   *              of the displayed text only, without mark-up markers.
   * @return The text content length >= 0
   * @throws BadLocationException
   */
  @Deprecated
  int getTextContentLength() throws BadLocationException;
  
  /**
   * Get access to the Author undo manager.
   * 
   * @return The Author undo manager. The returned undo manager cannot be <code>null</code>.
   */
  UndoManager getUndoManager();
  
  /**
   * Begin a compound edit. This method should be called
   * to signal to the editing support that a complex editing operation begins.
   * The editing operations that occur between <code>beginCompoundEdit()</code>
   * and <code>endCompoundEdit()</code> methods calls are regarded by the UndoManager 
   * as a single operation which can be undone/redone in one step.
   */
  void beginCompoundEdit();
  
  /**
   * End a compound edit. This method should be called
   * to signal to the editing support that a complex editing operation ends.
   * @see #beginCompoundEdit()
   */
  void endCompoundEdit();
  
  /**
   * Inserts a text at the given offset. After the operation the caret will be 
   * positioned at the end of the inserted text.
   * 
   * @param offset The insert position, 0 based.
   * @param text The text to be inserted.
   */
  void insertText(int offset, String text);
  
  /**
   * Insert an XML fragment at the given offset. 
   * After the operation the caret will be positioned at the end of the 
   * inserted XML fragment.
   * 
   * @param xmlFragment The XML fragment to insert.
   * @param offset The insert position, 0 based.
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  void insertXMLFragment(String xmlFragment, int offset) throws AuthorOperationException;
  
  /**
   * Insert an XML fragment relative to the node identified by the <code>xpathLocation</code> 
   * and according with the <code>relativePosition</code>.
   * Note: if the <code>xpathLocation</code> is not specified then the XML fragment 
   * will be inserted at caret position and the <code>relativePosition<code> will be ignored. 
   * <p>
   * After the operation the caret will be positioned at the end of the inserted XML fragment. 
   * 
   * @param xmlFragment The XML fragment.
   * @param xpathLocation The XPath location.
   * @param relativePosition The position relative to the node identified by the XPath location. 
   * Can be one of the constants: {@link AuthorConstants#POSITION_BEFORE}, {@link AuthorConstants#POSITION_AFTER},
   * {@link AuthorConstants#POSITION_INSIDE}.
   * @throws AuthorOperationException If the fragment could not be inserted.
   */
  void insertXMLFragment(String xmlFragment, String xpathLocation, String relativePosition) throws AuthorOperationException;
  
  /**
   * Insert an {@link AuthorDocumentFragment} at the given offset.
   * 
   * @param caretOffset The offset where the fragment will be inserted, 0 based.
   * @param frag The {@link AuthorDocumentFragment} to be inserted.
   */
  void insertFragment(int caretOffset, AuthorDocumentFragment frag);
  
  /**
   * Surround the content between the given offsets with the <code>xmlFragment</code>. 
   * If <code>endOffset < startOffset</code> the <code>xmlFragment</code> 
   * will be inserted at <code>startOffset</code>.
   * 
   * @param xmlFragment The XML fragment which will surround the given interval.
   * The first leaf node of the XML fragment will be the parent of the surrounded content.
   * @param startOffset The start offset of the content to be surrounded, 0 based and inclusive.
   * @param endOffset The end offset of the content to be surrounded, 0 based and inclusive.
   * @throws AuthorOperationException If the content between start and end offset could not be surrounded.
   */
  void surroundInFragment(String xmlFragment, int startOffset, int endOffset) throws AuthorOperationException;
  
  /**
   * Surround the content between the given offsets with plain text fragments(without XML parsing). 
   * The method inserts the <code>header</code> at <code>startOffset</code> and 
   * the <code>footer</code> at <code>endOffset</code>.
   * 
   * @param header The header to be inserted before the surrounded text.
   * @param footer The footer to be inserted after the surrounded text.
   * @param startOffset The start offset of the text to be surrounded, 0 based.
   * @param endOffset The end offset of the text to be surrounded, 0 based.
   * @throws AuthorOperationException If the operation failed.
   */
  void surroundInText(String header, String footer, int startOffset, int endOffset) throws AuthorOperationException;
  
  /**
   * Test if the context at the given <code>offset</code> is <b>inline</b> or not. 
   * <p>
   * For example a text paragraph determines an <b>inline</b> context, 
   * and for an offset inside this paragraph the method will return <code>true</code>. 
   * For an offset between two paragraphs (considered to be <b>block</b> level) 
   * the method will return <code>false</code>.
   * 
   * @param offset The offset in the document, zero based.
   * @return Returns <code>true</code> if the given offset is inside an inline context.
   * <code>false</code> otherwise.
   * @throws BadLocationException When the offset does not exists in the document content.
   * @throws AuthorOperationException If the operation failed.
   */
  boolean inInlineContext(int offset) throws BadLocationException, AuthorOperationException;
  
  /**
   * Add an Author listener to be notified about changes regarding the document 
   * and the document structure.
   * 
   * @param listener The {@link AuthorListener} to be added. 
   */
  void addAuthorListener(AuthorListener listener);
  
  /**
   * Remove an Author listener.
   * 
   * @param listener The {@link AuthorListener} to be removed. 
   */
  void removeAuthorListener(AuthorListener listener);
  
  /**
   * Evaluates an XPath expression.
   * This function returns the result of the given XPath expression as an array of {@link Object}.
   * Author DOM text nodes, DOM CDATA sections and DOM comment wrappers can be 
   * ignored for performance reasons.
   * <br>
   * For example, executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the Author DOM Node wrappers in the document.
   * <br>
   * while evaluating the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an array having a single component representing the number of nodes in the document.
   * <br>
   * Evaluating the expression:
   * <blockquote>
   * <code>//node(), count(//node())</code>
   * </blockquote>
   * will return an array containing all the Author DOM Node wrappers in the document and having as last component
   * the total number of nodes.
   * 
   * @param xpathExpression The XPath expression.
   * @param ignoreTexts If <code>true</code> DOM text nodes will not be returned.
   * @param ignoreCData If <code>true</code> DOM CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> DOM comments will not be returned.
   * @return An array of objects representing the XPath result.
   *         It does not return a <code>null</code> array. If the XPath evaluation fails it will return
   *         an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   */
  Object[] evaluateXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments) 
    throws AuthorOperationException;
  
  /**
   * Finds the author nodes selected by the given XPath expression.
   * The result of this function is an array of {@link AuthorNode} selected 
   * by the given XPath expression.
   * Author text nodes, Author CDATA section nodes and Author comment nodes 
   * can be ignored for performance reasons.
   * <br>
   * For example executing the expression:
   * <blockquote>
   * <code>//node()</code>
   * </blockquote>
   * will return an array with all the AuthorNode's in the document.
   * <br>
   * But the result of calling the function with the expression:
   * <blockquote>
   * <code>count(//node())</code>
   * </blockquote>
   * will return an empty array.
   * 
   * 
   * @param xpathExpression The XPath expression.
   * @param ignoreTexts If <code>true</code> Author text nodes will not be returned.
   * @param ignoreCData If <code>true</code> Author CDATA sections will not be returned.
   * @param ignoreComments If <code>true</code> Author comments will not be returned.
   * @return The Author nodes selected by the XPath expression.
   *         It does not return a <code>null</code> array of nodes.
   *         If the evaluation of the XPath expression fails it will return an empty array.
   * @throws AuthorOperationException If the XPath expression failed to be evaluated.
   */
  AuthorNode[] findNodesByXPath(String xpathExpression, boolean ignoreTexts, boolean ignoreCData, boolean ignoreComments) 
    throws AuthorOperationException;
  
  /**
   * Compute the document offset defined by the XPath location and relative position.
   * 
   * @param xpathLocation The XPath defining a node in document.
   * @param relativePosition  The relative position to the node. 
   * One of the following: {@link AuthorConstants#POSITION_BEFORE}, 
   * {@link AuthorConstants#POSITION_INSIDE} or
   * {@link AuthorConstants#POSITION_AFTER}
   * @return  The offset in document.
   * @throws AuthorOperationException If it fails.
   */
  public int getXPathLocationOffset(String xpathLocation, String relativePosition)
    throws AuthorOperationException;
  
  /**
   * Insert multiple elements at the given offsets.
   * <br>
   * Note: <i>The offsets and elements must be in document order.</i>
   * 
   * @param parentElement The parent element that contains all the new inserted 
   * elements. 
   * @param elementNames The element names to be inserted.
   * @param offsets The absolute offsets where the elements will be inserted.
   * @param namespace The namespace of the new inserted elements.
   */
  public void insertMultipleElements(AuthorElement parentElement, String[] elementNames,
      int[] offsets, String namespace);
  
  /**
   * Deletes the given intervals.
   * <br>
   * Note: <i>The offsets must be in document order and the intervals must not 
   * intersect with each other.</i>
   * 
   * @param parentElement The element that contains all the deleted intervals.
   * @param startOffsets The start offset for each interval.
   * Must be in document order.
   * @param endOffsets The end offset for each interval.
   * Must be in document order.
   */
  public void multipleDelete(
      AuthorElement parentElement, 
      int[] startOffsets, 
      int[] endOffsets);

  /**
   * Set a new internal document type to the Author content.
   * 
   * This is a good method to add new entities (regular or unparsed) to the internal document type of the document.
   * 
   * WARNING: if these modifications affect regular entities already inserted and expanded,
   * they will not be re-parsed and their old content will remain rendered as such. 
   * 
   * @param docType The document type information.
   */
  void setDoctype(AuthorDocumentType docType);
  
  /**
   * Returns information about the internal associated document type.
   * 
   * @return The internal associated document type information.
   *         If the document does not have an internal Doctype section 
   *         the method will return <code>null</code>.
   */
  AuthorDocumentType getDoctype();
  
  /**
   * Find the common ancestor node of the two offsets.
   * 
   * @param doc The author document.
   * @param startOffset The start offset.
   * @param endOffset The end offset.
   * @return The common ancestor. Can be the document but it cannot be <code>null</code>.
   * @throws BadLocationException
   */
  AuthorNode getCommonParentNode(AuthorDocument doc, int startOffset, int endOffset) throws BadLocationException;
  
  /**
   * Returns the edited author document.
   * 
   * @return The author document. The document cannot be <code>null</code>.
   */
  AuthorDocument getAuthorDocumentNode();
  
  /**
   * Sets the {@link AuthorDocumentFilter} to be used for altering the document edits.
   * 
   * @param authorDocumentFilter The {@link AuthorDocumentFilter} to be used.
   */
  void setDocumentFilter(AuthorDocumentFilter authorDocumentFilter);
  
  /**
   * The content represents the entire text content of the Author page + additional markers/sentinels 
   * at offsets which are pointed to by the AuthorNodes.
   * Each AuthorNode points to specific start and end character markers in the content.
   * The start and end offsets pointed to by the AuthorNode can be retrieved using the
   * AuthorNode.getStartOffset() and AuthorNode.getEndOffset()
   *  
   * <br/>
   * <img src="node/AuthorDocumentFragmentArchitecture.gif"/>
   * <br/>
   * 
   * Retrieves a portion of the content into the specified {@link Segment}. 
   *
   * @param where The starting position >= 0, where + len <= length()
   * @param len The number of characters to be retrieved >= 0
   * @param chars The {@link Segment} object to return the characters int.o
   * @exception BadLocationException If the specified position or length are invalid.
   */
  public void getChars(int where, int len, Segment chars) throws BadLocationException;
}