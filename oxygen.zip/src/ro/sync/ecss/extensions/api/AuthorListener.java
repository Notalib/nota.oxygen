/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import ro.sync.ecss.extensions.api.node.AuthorDocument;
import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Listener notified about Author document changes, document structure changes and 
 * document content changes.
 */
public interface AuthorListener {
  /**
   * Called before some content is deleted from the document.
   *
   * @param e The {@link DocumentContentDeletedEvent}.
   */
  void beforeContentDelete(DocumentContentDeletedEvent e);

  /**
   * Called when an attribute is about to be changed in one of the document's
   * elements.
   * 
   * @param e The {@link AttributeChangedEvent}.
   */
  void beforeAttributeChange(AttributeChangedEvent e);
  
  /**
   * Called when content is about to be inserted into a document.
   *
   * @param e The {@link DocumentContentInsertedEvent}.
   */
  void beforeContentInsert(DocumentContentInsertedEvent e);

  /**
   * Called before the DOCTYPE section is about to be changed.
   */
  void beforeDoctypeChange();

  /**
   * Called when a node structure is about to be changed.
   *  
   * @param authorNode The {@link AuthorNode} that contains the modification.
   */
  void beforeAuthorNodeStructureChange(AuthorNode authorNode);
  
  /**
   * Called when a node name is about to be changed.
   * <br>
   * <em>The <code>authorNode</code> is a reference to the actual node in the 
   * {@link AuthorDocument} so its name will be changed after the name change 
   * operation is completed.
   * <br>
   * If the old name of the node will be needed after the call of this method it should be 
   * obtained and saved during this method call.</em>
   *  
   * @param authorNode The {@link AuthorNode} that will be changed.
   */
  void beforeAuthorNodeNameChange(AuthorNode authorNode);
  
  /**
   * Called when an Author attribute is changed in one of the document's elements.
   * 
   * @param e The {@link AttributeChangedEvent}.
   */
  void attributeChanged(AttributeChangedEvent e);
  
  /**
   * This is called when a node has been renamed.
   * 
   * @param node The {@link AuthorNode} that was renamed.
   */
  void authorNodeNameChanged(AuthorNode node);
  
  /**
   * The node structure has been changed. 
   * An insert or delete operation 
   * has been made and affected the children of the node. 
   * 
   * @param node The {@link AuthorNode} that contains the modification.
   */
  void authorNodeStructureChanged(AuthorNode node);
  
  /**
   * A new document has been set into the author page.
   * 
   * @param oldDocument The old Author document
   * @param newDocument The new Author document.
   */
  void documentChanged(AuthorDocument oldDocument, AuthorDocument newDocument);
  
  /**
   * Called when content is deleted from the document.
   *
   * @param e The {@link DocumentContentDeletedEvent}.
   */
  void contentDeleted(DocumentContentDeletedEvent e); 
  
  /**
   * Called when content is inserted into the document.
   *
   * @param e The {@link DocumentContentInsertedEvent}.
   */
  public void contentInserted(DocumentContentInsertedEvent e);
  
  /**
   * The DOCTYPE section has been changed.
   */
  public void doctypeChanged();
}