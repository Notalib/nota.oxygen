package ro.sync.ecss.extensions.api;

import java.util.StringTokenizer;

/**
 * Specifies the fixed and relative width determined from the value of width/colwidth 
 * attribute.
 * 
 */
public class WidthRepresentation {
  /**
   * The default width representation.
   */
  public static WidthRepresentation DEFAULT_WIDTH_REPRESENTATION = new WidthRepresentation(0, null, 0, false); 

  /**
   * The fixed width unit. 
   */
  public enum Unit {
    /**
     * Centimeters are converted to inches and then multiplied with the dots per inch.
     * The value is <code>cm</code>.
     */
    CENTIMETER("cm"), 
    /**
     * The EM is relative to the font size. 1 is the font size.
     * The value is <code>em</code>. 
     */
    EM("em"), 
    /**
     * The EX is relative the the height of the "x" character.
     * The value is <code>ex</code>.
     */
    EX("ex"), 
    /**
     * Value in inches are multiplied with the dots per inch value.
     * The value is <code>in</code>.
     */
    INCH("in"), 
    /**
     * Value in millimeter is converted to inches and then to pixels. 
     * The value is <code>mm</code>.
     */
    MILLIMETER("mm"), 
    /**
     * Pica is a unit of measure equal to 12 points or one sixth of an inch.
     * The value is <code>pc</code>.
     */
    PICA("pc"),
    /**
     * Directly in pixels. No conversion needed.
     * The value is <code>px</code>.
     */
    PIXEL("px"), 
    /**
     * A point is approximately 1/72 inch.
     * The value is <code>pt</code>.
     */
    POINT("pt");

    /**
     * A string representation of the unit.
     */
    private String unitRepresentation;

    /**
     * Constructor.
     * 
     * @param representation The string representation of the unit.
     */
    private Unit(String representation) {
      this.unitRepresentation = representation;
    }

    /**
     * @see java.lang.Enum#toString()
     */
    @Override
    public String toString() {
      return unitRepresentation;
    }
  }

  /**
   * The fixed width value.
   */
  private float fixedWidth;

  /**
   * The fixed width unit.
   */
  private Unit fixedWidthUnit = Unit.PIXEL;

  /**
   * The relative width. This value can be relative to the parent width, 
   * or relative to the other siblings.
   * 
   */
  private float relativeWidth;

  /**
   * If <code>true</code> then the relativeWidth represents a percentage of the   
   * parent width, otherwise the relativeWidth will be computed taking into account 
   * the other siblings widths.
   */
  private boolean isRelativeToParent;

  /**
   * Constructor.
   * 
   * @param fixedWidth        The fixed width part. 
   * @param fixedWidthUnit    The unit of fixed width. Defaults to PIXEL.
   * @param relativeWidth     The relative width part.
   * @param isRelativeToParent  If <code>true</code> then the relative width represents
   *        a percentage of the parent table width, otherwise the relative value
   *        represent a proportional width which is evaluated taking into account 
   *        the proportional values of the other columns.    
   *        <br/>For example, if there are two columns with 70% and 30% relative widths then
   *        the table total width will be divided according with this values. 
   *        <br/>If the relative widths for the two columns are specified in proportional units and,
   *        for example, have the values 1 for the first column and 2 for the second column
   *        then the second column will be twice as large as the first one.
   */
  public WidthRepresentation(float fixedWidth, Unit fixedWidthUnit, float relativeWidth, boolean isRelativeToParent) {
    this.fixedWidth = fixedWidth;
    if (fixedWidthUnit != null) {
      this.fixedWidthUnit = fixedWidthUnit;
    }
    this.relativeWidth = relativeWidth;
    this.isRelativeToParent = isRelativeToParent;
  }
  
  /**
   * Constructor.
   * Create a ColWidth corresponding to the given width representation.
   * 
   * @param widthRepresentation The string representation of the Width. The 
   *      representation format must be a sum of terms with the following format: 
   *      n(*|%|units). If there are more that one terms with the same form (fixed 
   *      or relative) then corresponding width (fixed or relative) will be reseted.
   * @param acceptPercents If <code>true</code> then percentage values are
   *      accepted
   */
  public WidthRepresentation(String widthRepresentation, boolean acceptPercents) {
    // The fixed width value.
    this.fixedWidth = 0f;
    // The fixed width unit.
    this.fixedWidthUnit = Unit.PIXEL;
    // The relative width. This value can be relative to the parent width, 
    // or relative to the other siblings.
    this.relativeWidth = 0f;
    // If <code>true</code> then the relativeWidth represents a percentage of the   
    // parent width, otherwise the relativeWidth will be computed taking into account 
    // the other siblings widths.
    this.isRelativeToParent = false;
    
    if (widthRepresentation != null) {

      // The string will be tokenized by the "+" delimiter
      StringTokenizer tokenizer = new StringTokenizer(widthRepresentation, "+");
      boolean fixedSpecified = false;
      boolean relativeSpecified = false;
      boolean resetRelativeWidth = false;
      boolean resetFixedWidth = false;

      while (tokenizer.hasMoreElements()) {
        String token = ((String) tokenizer.nextElement()).trim();
        if (token.length() > 0) {
          char lastChar = token.charAt(token.length() - 1);
          // Try to find the percentage part of the width
          if (lastChar == '%') {
            // Verify if the relative part of the width has already been specified
            if (!relativeSpecified) {
              relativeSpecified = true;
              // Verify if the percentage values are allowed
              if (acceptPercents) {
                String percentage = token.substring(0, token.length() - 1);
                try {
                  // Find the relative width value.
                  relativeWidth = Float.parseFloat(percentage) / 100;
                  // The relative with is relative to the parent (percentage value)
                  isRelativeToParent = true;
                } catch (NumberFormatException e) {
                  resetRelativeWidth = true;
                }
              } else {
                resetRelativeWidth = true; 
              }
            } else {
              // If the percentage width are not allowed reset the relative width.
              resetRelativeWidth = true;
            }
          } else if (lastChar == '*') {
            // Try to find the proportion part of the width
            if (!relativeSpecified) {
              relativeSpecified = true;
              String proportion = token.substring(0, token.length() - 1);
              try {
                // Find the relative width value.
                if (proportion.length() == 0) {
                  // '*' it means '1*'
                  relativeWidth = 1;
                } else {
                  relativeWidth = Float.parseFloat(proportion);
                }
                // The relativeWidth will be computed taking into account 
                // the other siblings widths (proportion value)
                isRelativeToParent = false;
              } catch (NumberFormatException e) {
                // Reset the relative width if there was specified a value with 
                // wrong format
                resetRelativeWidth = true; 
              }
            } else {
              // Reset the relative width if a relative value has already been computed 
              resetRelativeWidth = true;
            }
          } else {
            if (!fixedSpecified) {
              fixedSpecified = true;
              // Try to obtain a lexicalUnit.
              int tokenLength = token.length();
              if (tokenLength > 1) {
                try {
                  String unit = token.substring(tokenLength - 2);
                  // By default, the unit lenght is 2
                  int unitLength = 2;
                  if ("cm".equals(unit)) {
                    fixedWidthUnit = Unit.CENTIMETER;
                  } else if ("em".equals(unit)) {
                    fixedWidthUnit = Unit.EM;
                  } else if ("ex".equals(unit)) {
                    fixedWidthUnit = Unit.EX;
                  } else if ("in".equals(unit)) {
                    fixedWidthUnit = Unit.INCH;
                  } else if ("mm".equals(unit)) {
                    fixedWidthUnit = Unit.MILLIMETER;
                  } else if ("pc".equals(unit)) {
                    fixedWidthUnit = Unit.PICA;
                  } else if ("px".equals(unit)) {
                    fixedWidthUnit = Unit.PIXEL;
                  } else if ("pt".equals(unit)) {
                    fixedWidthUnit = Unit.POINT;
                  } else {
                    // unit length is 0
                    unitLength = 0;
                    fixedWidthUnit = Unit.PIXEL;
                  }
                  if (unitLength == 0) {
                    fixedWidth = Float.parseFloat(token);
                  } else {
                    fixedWidth = Float.parseFloat(token.substring(0, tokenLength - unitLength));
                  }
                } catch (NumberFormatException e) {
                  // No valid fixed width detected. 
                }
              }
            } else {
              resetFixedWidth = true;
            }
          }
        }
      }

      // Reset the relative width.
      if (resetRelativeWidth) {
        relativeWidth = 0;
      } 

      // Reset the relative width.
      if (resetFixedWidth) {
        fixedWidth = 0;
      } 
    }
  }

  /**
   * @return Returns the fixed width part of the width representation.
   */
  public float getFixedWidth() {
    return fixedWidth;
  }
  
  /**
   * @return Returns the fixed width unit.
   */
  public Unit getFixedWidthUnit() {
    return fixedWidthUnit;
  }
  
  /**
   * @return Returns the relative width part of the width representation.
   */
  public float getRelativeWidth() {
    return relativeWidth;
  }
  
  /**
   * @return Returns <code>true</code> if the relative part of the width is expressed
   * relative to the parent width, <code>false</code> if is expressed relative to other siblings.
   */
  public boolean isRelativeToParent() {
    return isRelativeToParent;
  }

  /**
   * @return <code>true</code> if the current width representation should be taken
   * into account when building the layout. 
   */
  public boolean isApplicable() {
    return relativeWidth > 0 || fixedWidth > 0;
  }

  /**
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return (isRelativeToParent ? ("(" + relativeWidth + ")" + (relativeWidth * 100) + "%") : (relativeWidth + "*")) + " + " + fixedWidth + fixedWidthUnit;
  }
  
  /**
   * @return The string representation of the width. The format of the width is 
   * <br/>
   * <code>
   * [fixed_width][fixed_width_unit] + [relative_width %|*] 
   * </code>
   * 
   */
  public String getWidthRepresentation() {
    String toReturn = null;
    boolean hasRelativePart = relativeWidth > 0;
    boolean hasFixedPart = fixedWidth > 0;
    if (hasRelativePart) {
      toReturn = 
        (isRelativeToParent() ? 
            Math.round(relativeWidth * 100) + "%" 
            : (relativeWidth + "*"));
      if (hasFixedPart) {
        toReturn += " + " + fixedWidth + fixedWidthUnit;
      }
    } else if (hasFixedPart) {
      toReturn = String.valueOf(fixedWidth) + fixedWidthUnit;
    }
    return toReturn;
  }
}