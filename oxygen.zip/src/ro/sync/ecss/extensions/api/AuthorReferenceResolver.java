/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import javax.xml.transform.sax.SAXSource;

import org.xml.sax.EntityResolver;
import org.xml.sax.InputSource;

import ro.sync.ecss.extensions.api.node.AuthorNode;

/**
 * Interface for the custom handlers used to expand content references.
 */
public interface AuthorReferenceResolver extends Extension {
  /**
   * Verifies if the handler considers the node to have references.
   * <br>
   * For example the method should return <code>true</code> for 
   * a DITA element that has <code>conref</code> attribute set. 
   * 
   * @param node The node to be analyzed.
   * @return <code>true</code> if it has references.
   */
  boolean hasReferences(AuthorNode node);
  
  /**
   * Verifies if the references of the given node must be refreshed 
   * when the attribute with the specified name has changed.
   * <br>
   * For example the DITA implementation returns <code>true</code> 
   * when the attribute name is equal to <code>'conref'</code>.
   * 
   * @param node The {@link AuthorNode} with the references.
   * @param attributeName The name of the changed attribute.
   * @return <code>true</code> if the references must be refreshed.
   */
  boolean isReferenceChanged(AuthorNode node, String attributeName);
  
  /**
   * Resolve the references of the node. 
   * The returning {@link SAXSource} will be used for creating the referred content 
   * using the parser and the source inside it.
   * </br>
   * For example the DITA implementation resolves the content referred by the
   * <code>conref</code> attribute.
   * 
   * @param node        The node which has references.
   * @param systemID    The system ID of the node with references.
   * @param authorAccess The author access implementation.
   * Provides access to specific informations and actions for 
   * editor, document, workspace, tables, change tracking, utility a.s.o.
   * @param entityResolver The entity resolver that can be used to resolve: 
   * 
   * <ul>
   *  <li>Resources that are already opened in editor. 
   *  For this case the {@link InputSource} will contain the editor content.</li>
   *  <li>Resources resolved through XML catalog.</li>
   * </ul>
   * 
   * @return The {@link SAXSource} including the parser and the parser's {@link InputSource}.
   */
  SAXSource resolveReference(AuthorNode node, String systemID, AuthorAccess authorAccess, EntityResolver entityResolver);
  
  /**
   * Returns the name of the node that contains the expanded referred content.
   * <br>
   * For example the value of the <code>conref</code> attribute is returned
   * by the DITA implementation.
   * 
   * @param node The node that contains references.
   * @return The display name of the node.
   */
  String getDisplayName(AuthorNode node);

  /**
   * Get an unique identifier for the node reference. 
   * The unique identifier is used to avoid resolving the references recursively.
   * <br>
   * For example the DITA implementation uses the value of the 
   * <code>conref</code> attribute as the unique identifier.
   * 
   * @param node The node that has reference.
   * @return  An unique identifier for the reference node.
   */
  String getReferenceUniqueID(AuthorNode node);

  /**
   * Return the systemID of the referred content.
	 *
   * @param node The reference node.
   * @param authorAccess The author access. It provides access to specific 
   * informations and actions for editor, document, workspace, tables, 
   * change tracking, utility a.s.o.
   * @return The systemID of the referred content.
   */
  String getReferenceSystemID(AuthorNode node, AuthorAccess authorAccess);
}