/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2007 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api.highlights;

import ro.sync.exml.view.graphics.Color;

/**
 * Paint spell check markers on a view.
 */
public class ColorHighlightPainter implements HighlightPainter{
  
  
  /**
   * The hight of the highlight line. This may be smaller than the total height. If it is, the extra space
   * will remain under the line.
   */
  private int height = -1;
  
  /**
   * The height of the highlight.
   */
  private int totalHeight = 1;

  /**
   * Strike out style
   */
  private boolean strikeOut;

  /**
   * The BG color.
   */
  private Color bgColor;

  /**
   * Default constructor. The color is red.
   */
  public ColorHighlightPainter() {
  }

  /**
   * Constructor. 
   * 
   * @param color The color to use for highlight.
   * @param  height The height of the highlight line. This may be smaller than the total height. If it is, the extra space
   * will remain under the line.
   * @param totalHeight The height of the highlight.
   */
  public ColorHighlightPainter(Color color, int height, int totalHeight) {
    this.color = color;
    this.height = height;
    this.totalHeight = totalHeight;
  }

  
  /**
   * The color.
   */
  private Color color = Color.COLOR_RED_DARKER;

  /**
   * @see ro.sync.ecss.extensions.api.highlights.HighlightPainter#paint(ro.sync.ecss.extensions.api.highlights.HighlightPainterInfo)
   */
  public void paint(HighlightPainterInfo pi) {
    int stroke = height;
    if(stroke == -1) {
      //The height is not specified so we'll have to determine it from the font size.
      stroke = (int) Math.max(1, Math.round(((double)pi.getFontSize())/10));
      totalHeight = stroke + 1;
    }

    //Strike out or underline.
    pi.getGraphics().setFillColor(color);
    int y = pi.getOrigin().y;
    if(strikeOut) {
      y += pi.getBaseLine() - pi.getFontAscent()/3;
    } else {
      if(useBaseLineForUnderline() && pi.isHighlightOverText()) {
        y += pi.getBaseLine() + 1; 
      } else {
        y += pi.getCurrentBoxHeight() - totalHeight;
      }
    }
    pi.getGraphics().fillRect(pi.getOrigin().x + pi.getRelativeX(), y, pi.getLength(), stroke);
    
    if(bgColor != null) {
      //Also fill background.
      pi.getGraphics().setFillColor(bgColor);
      pi.getGraphics().fillRect(pi.getOrigin().x + pi.getRelativeX(), pi.getOrigin().y, 
          pi.getLength(), pi.getCurrentBoxHeight());
    }
  }

  /**
   * Set the color.
   * @param c  The color.
   */
  public void setColor(Color c) {
    this.color = c; 
  }
  
  /**
   * @param strikeOut Set this highlight as strike out.
   */
  public void setStrikeOut(boolean strikeOut) {
    this.strikeOut = strikeOut;
  }
  
  /**
   * @param bgColor The background color to set.
   */
  public void setBgColor(Color bgColor) {
    this.bgColor = bgColor;
  }
  
  /**
   * @return true if use the base line for underlining
   */
  public boolean useBaseLineForUnderline() {
    return false;
  }
}
