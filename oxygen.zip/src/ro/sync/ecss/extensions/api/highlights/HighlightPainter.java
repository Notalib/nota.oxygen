package ro.sync.ecss.extensions.api.highlights;


/**
 * Highlight renderer.
 */
public interface HighlightPainter {

  /**
   * Renders the highlight.
   * @param pi Information used by highlight
   */
  public void paint(HighlightPainterInfo pi);
}