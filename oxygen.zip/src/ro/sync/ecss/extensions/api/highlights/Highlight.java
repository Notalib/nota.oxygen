package ro.sync.ecss.extensions.api.highlights;

/**
 * The highlight interface.
 */
public interface Highlight {

  /**
   * Gets the starting model offset for the highlight.
   *
   * @return the starting offset >= 0
   */
  public int getStartOffset();

  /**
   * Gets the ending model offset for the highlight.
   *
   * @return the ending offset >= 0
   */
  public int getEndOffset();
  
  /**
   * @return Additional data for the highlight.
   */
  public Object getAdditionalData();

  /**
   * Gets the painter for the highlighter.
   *
   * @return the painter
   */
  public HighlightPainter getPainter();
}