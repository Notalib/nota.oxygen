/*
 *  The Syncro Soft SRL License
 *
 *  Copyright (c) 1998-2009 Syncro Soft SRL, Romania.  All rights
 *  reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *  1. Redistribution of source or in binary form is allowed only with
 *  the prior written permission of Syncro Soft SRL.
 *
 *  2. Redistributions of source code must retain the above copyright
 *  notice, this list of conditions and the following disclaimer.
 *
 *  3. Redistributions in binary form must reproduce the above copyright
 *  notice, this list of conditions and the following disclaimer in
 *  the documentation and/or other materials provided with the
 *  distribution.
 *
 *  4. The end-user documentation included with the redistribution,
 *  if any, must include the following acknowledgment:
 *  "This product includes software developed by the
 *  Syncro Soft SRL (http://www.sync.ro/)."
 *  Alternately, this acknowledgment may appear in the software itself,
 *  if and wherever such third-party acknowledgments normally appear.
 *
 *  5. The names "Oxygen" and "Syncro Soft SRL" must
 *  not be used to endorse or promote products derived from this
 *  software without prior written permission. For written
 *  permission, please contact support@oxygenxml.com.
 *
 *  6. Products derived from this software may not be called "Oxygen",
 *  nor may "Oxygen" appear in their name, without prior written
 *  permission of the Syncro Soft SRL.
 *
 *  THIS SOFTWARE IS PROVIDED ``AS IS'' AND ANY EXPRESSED OR IMPLIED
 *  WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
 *  OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 *  DISCLAIMED.  IN NO EVENT SHALL THE SYNCRO SOFT SRL OR
 *  ITS CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
 *  USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 *  ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
 *  OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT
 *  OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 *  SUCH DAMAGE.
 */
package ro.sync.ecss.extensions.api;

import java.util.List;

import ro.sync.ecss.extensions.api.node.AuthorElement;

/**
 * This is an interface for classes which are responsible for providing information
 * and handling modifications regarding table and column widths.
 * It should be implemented when the author extension being developed offers
 * support for editing data in tabular form.
 */
public interface AuthorTableColumnWidthProvider extends Extension {
  /**
   * Get the width representation for the cell represented by the <code>cellElement</code>.
   * <br>
   * For example for a CALS table cell the list with the width representations is obtained by 
   * computing the column span and then determining the {@link WidthRepresentation}
   * for each column the cell spans across.
   *
   * @param cellElement   	The node that represents a table cell in CSS.
   * @param colNumberStart 	The column number the cell starts at.
   * @param colSpan 		    The column span of the cell.
   * @return              	The list with the {@link WidthRepresentation} of the specified cell element. 
   * If the cell spans over multiple columns then the returned list will contain one {@link WidthRepresentation} 
   * for each column the cell spans over.
   */
  List<WidthRepresentation> getCellWidth(AuthorElement cellElement, int colNumberStart, int colSpan);
  
  /**
   * This method is called when starting to compute the layout for a table. Its intended
   * to extract information from the element representing the table only once, not on every 
   * getColSpan() or getRowSpan() call.
   * <br> 
   * Example: for a DocBook table we identify and cache
   * the 'colspec' and 'spanspec' elements from that table.
   * 
   * A new instance of the table column width provider is used for every table in a document 
   * so cached data cannot be reused between different tables.
   * 
   * @param tableElement The element representing a table (it has the CSS display property 
   * set on 'table').
   */
  void init(AuthorElement tableElement);
  
  /**
   * Updates the column widths in the document and in the column layout model.
   * <br>
   * For example, for the DocBook CALS tables the method updates the columns 
   * width specifications in the source document by setting the <code>colwidth</code> 
   * attribute value of the <code>colspec</code> elements. 
   * New <code>colspec</code> elements will be added if needed.
   * 
   * @param authorDocumentController The {@link AuthorDocumentController} used to commit the table modifications
   * in the document. 
   * @param colWidths  The new column {@link WidthRepresentation} to set. The column widths must be ordered 
   * according to the corresponding column numbers.
   * @param tableCellsTagName The cells tag name. Used to identify the table type (e.g. 'entry' for CALS or 'td' for HTML). 
   * @throws AuthorOperationException If the operation fails.
   */
  void commitColumnWidthModifications(
      AuthorDocumentController authorDocumentController, WidthRepresentation[] colWidths, String tableCellsTagName) throws AuthorOperationException;
  
  /**
   * Commit the table width modification.
   * <br>
   * For example in the case of DocBook HTML tables sets the 
   * <code>width</code> attribute value of the <code>table</code> element.
   * 
   * @param authorDocumentController  The {@link AuthorDocumentController} used to commit the table width modifications
   * in the document. 
   * @param newTableWidth The new table {@link WidthRepresentation} to set. The value is given in pixels.
   * @param tableCellsTagName The cells tag name. Used to identify the table type (e.g. 'entry' for CALS or 'td' for HTML). 
   * @throws AuthorOperationException If the operation fails.
   */
  void commitTableWidthModification(
      AuthorDocumentController authorDocumentController, int newTableWidth, String tableCellsTagName) throws AuthorOperationException;
  
  /**
   * Used to determine if the table accepts width specification.
   * <br>
   * For example, for the DocBook CALS tables which do not accept 
   * an <code>width</code> attribute the method will return <code>false</code>.
   * 
   * @param tableCellsTagName The cells tag name. Used to identify the table type (e.g. 'entry' for CALS or 'td' for HTML). 
   * @return <code>true</code> if the table type denoted by the <code>tableCellsTagName</code> accepts width specification
   * of any kind.
   */
  boolean isTableAcceptingWidth(String tableCellsTagName);
  
  /**
   * Returns a non null {@link WidthRepresentation} if the table width is currently known.
   * <br>
   * For the DocBook HTML tables it returns the {@link WidthRepresentation} obtained by analyzing the
   * <code>width</code> attribute value of the <code>table</code> element. 
   * 
   * @param tableCellsTagName The cells tag name. Used to identify the table type (e.g. 'entry' for CALS or 'td' for HTML). 
   * @return A non <code>null</code> value if the table width is specified. Otherwise <code>null</code>.
   */
  WidthRepresentation getTableWidth(String tableCellsTagName);
  
  /**
   * This method is used to check if the table and/or table columns can be resized.
   * <br>
   * For example in the case of the DocBook CALS tables will return <code>true</code>
   * only if the given table cells tag name is equal to <code>'entry'</code>.  
   * 
   * @param tableCellsTagName The cells tag name. Used to identify the table type (e.g. CALS or HTML). 
   * @return <code>true</code> if the size of the table or the table cells can be adjusted.
   */
  boolean isTableAndColumnsResizable(String tableCellsTagName);
  
  /**
   * Check if the table column widths can be represented as fixed values.
   * 
   * @param tableCellsTagName The cells tag name. Used to identify the table type
   * (e.g. CALS or HTML).
   * @return <code>true</code> if the table column widths can be represented in 
   * fixed values.
   */
  boolean isAcceptingFixedColumnWidths(String tableCellsTagName);
  
  /**
   * Check if the table column widths can be represented as proportional values.
   * 
   * @param tableCellsTagName The cells tag name. Used to identify the table type
   * (e.g. CALS or HTML).
   * @return <code>true</code> if the table column widths can be represented in 
   * proportional values.
   */
  boolean isAcceptingProportionalColumnWidths(String tableCellsTagName);
  
  /**
   * Check if the table column widths can be represented as percentage values.
   * 
   * @param tableCellsTagName The cells tag name. Used to identify the table type
   * (e.g. CALS or HTML).
   * @return <code>true</code> if the table column widths can be represented in 
   * percentage values.
   */
  boolean isAcceptingPercentageColumnWidths(String tableCellsTagName);
}